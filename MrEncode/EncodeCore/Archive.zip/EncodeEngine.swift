//
//  EncodeEngine.swift
//  MrEncode
//
//  Created by scott ulrich on 2/2/26.
//


import Foundation
import AVFoundation
import VideoToolbox
import Accelerate
import CoreGraphics


struct EncodeRequest: Sendable {
    let inputURL: URL
    let outputURL: URL
    let allowOverwrite: Bool
    let settings: Settings
    let meta: MediaMetadata
    let filenameForOverlay: String
    let videoFrameHook: (@Sendable (CVPixelBuffer, FrameContext) -> Void)?

    init(
        inputURL: URL,
        outputURL: URL,
        allowOverwrite: Bool,
        settings: Settings,
        meta: MediaMetadata,
        filenameForOverlay: String,
        videoFrameHook: (@Sendable (CVPixelBuffer, FrameContext) -> Void)? = nil
    ) {
        self.inputURL = inputURL
        self.outputURL = outputURL
        self.allowOverwrite = allowOverwrite
        self.settings = settings
        self.meta = meta
        self.filenameForOverlay = filenameForOverlay
        self.videoFrameHook = videoFrameHook
    }
}

struct FrameContext: Sendable {
    public let frameIndex: Int64
    public let presentationTime: CMTime
    public let nominalFPS: Double
}

enum EncodeEngine {

    public static func encode(
        _ req: EncodeRequest,
        cancel: @escaping CancelCheck,
        emit: @escaping EncodeEventSink
    ) -> Result<EncodeResult, EncodeError> {

        emit(.phase(.preparing))

        // Resolve temp URL inside engine (shared behavior for GUI + CLI)
        let tempURL: URL
        do {
            tempURL = try TempOutputStrategy.makeTempURL(for: req.outputURL)
        } catch {
            let e = EncodeError(.unknown, "Unable to resolve temp output URL: \(error)")
            emit(.failed(e))
            return .failure(e)
        }


        // Ensure output dir exists
        do {
            try FileManager.default.createDirectory(
                at: req.outputURL.deletingLastPathComponent(),
                withIntermediateDirectories: true,
                attributes: nil
            )
        } catch {
            let e = EncodeError(.finalizeFailed, "Cannot create output folder: \(error.localizedDescription)")
            emit(.failed(e))
            return .failure(e)
        }

        emit(.phase(.probingSource))

        let needsOverlays = req.settings.burnInTimecode || req.settings.burnInFrames || req.settings.burnInFilename
        let asset = AVAsset(url: req.inputURL)

        guard let videoTrack = asset.tracks(withMediaType: .video).first else {
            let e = EncodeError(.invalidInput, "No video track found.")
            emit(.failed(e))
            return .failure(e)
        }

        let durationSeconds = req.meta.durationSeconds
        let frameDur = EncodeCore.snappedFrameDuration(for: videoTrack)
        let fps = EncodeCore.snappedFPS(for: videoTrack)

        let target  = EncodeCore.computeTargetDimensions(videoTrack: videoTrack, settings: req.settings)
        let aligned = EncodeCore.alignDimensions(target, alignment: 2)

        emit(.phase(.buildingPipeline))


        // Reader
        let reader: AVAssetReader
        do {
            reader = try AVAssetReader(asset: asset)
        } catch {
            let e = EncodeError(.readerFailed, "Reader init failed: \(error.localizedDescription)")
            emit(.failed(e))
            return .failure(e)
        }

        let videoComposition = EncodeCore.makeVideoComposition(
            track: videoTrack,
            contentSize: target,
            renderSize: aligned,
            settings: req.settings
        )

        let videoOutput = AVAssetReaderVideoCompositionOutput(
            videoTracks: [videoTrack],
            videoSettings: [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
        )
        videoOutput.videoComposition = videoComposition
        videoOutput.alwaysCopiesSampleData = false

        guard reader.canAdd(videoOutput) else {
            let e = EncodeError(.pipelineFailed, "Cannot add video output to reader.")
            emit(.failed(e))
            return .failure(e)
        }
        reader.add(videoOutput)

        // Audio reader
        let audioTrack = asset.tracks(withMediaType: .audio).first
        var audioOutput: AVAssetReaderOutput?
        if let at = audioTrack {
            let ao = AVAssetReaderTrackOutput(track: at, outputSettings: EncodeCore.audioReaderSettings)
            ao.alwaysCopiesSampleData = false
            if reader.canAdd(ao) {
                reader.add(ao)
                audioOutput = ao
            }
        }

        // Writer
        let writer: AVAssetWriter
        do {
            let fileType: AVFileType = (req.settings.containerFormat == .mp4) ? .mp4 : .mov
            writer = try AVAssetWriter(outputURL: tempURL, fileType: fileType)
        } catch {
            let e = EncodeError(.writerFailed, "Writer init failed: \(error.localizedDescription)")
            emit(.failed(e))
            return .failure(e)
        }

        writer.movieTimeScale = (frameDur.timescale > 1000) ? frameDur.timescale : CMTimeScale(60000)
        writer.shouldOptimizeForNetworkUse = true

        var vidSettings = EncodeCore.videoInputSettings(
            settings: req.settings,
            width: aligned.width,
            height: aligned.height,
            fps: fps
        )

        if let triplet = EncodeCore.nclcTripletToApply(settings: req.settings, meta: req.meta) {
            vidSettings[AVVideoColorPropertiesKey] = EncodeCore.nclcToAVVideoColorProperties(triplet: triplet)
        }

        let videoInput = AVAssetWriterInput(mediaType: .video, outputSettings: vidSettings)
        videoInput.expectsMediaDataInRealTime = false
        videoInput.mediaTimeScale = frameDur.timescale
        videoInput.transform = CGAffineTransform.identity

        let adaptor = AVAssetWriterInputPixelBufferAdaptor(
            assetWriterInput: videoInput,
            sourcePixelBufferAttributes: [
                kCVPixelBufferPixelFormatTypeKey as String: (req.settings.codec == .hevc
                    ? kCVPixelFormatType_420YpCbCr10BiPlanarFullRange
                    : kCVPixelFormatType_32BGRA),
                kCVPixelBufferWidthKey  as String: aligned.width,
                kCVPixelBufferHeightKey as String: aligned.height
            ]
        )

        guard writer.canAdd(videoInput) else {
            let e = EncodeError(.pipelineFailed, "Cannot add video input to writer.")
            emit(.failed(e))
            return .failure(e)
        }
        writer.add(videoInput)

        // Audio input
        var audioInput: AVAssetWriterInput?
        if audioTrack != nil {
            let ai = AVAssetWriterInput(mediaType: .audio, outputSettings: EncodeCore.audioOutputSettings)
            ai.expectsMediaDataInRealTime = false
            if writer.canAdd(ai) {
                writer.add(ai)
                audioInput = ai
            }
        }

        // Start I/O
        guard writer.startWriting() else {
            let e = EncodeError(.writerFailed, "Writer start failed: \(writer.error?.localizedDescription ?? "Unknown")")
            emit(.failed(e))
            return .failure(e)
        }
        guard reader.startReading() else {
            let e = EncodeError(.readerFailed, "Reader start failed: \(reader.error?.localizedDescription ?? "Unknown")")
            emit(.failed(e))
            return .failure(e)
        }
        writer.startSession(atSourceTime: .zero)

        emit(.phase(.encodingVideo))
        if audioOutput != nil && audioInput != nil {
            emit(.phase(.encodingAudio))
        }

        // Shared completion + failure state
        let failLock = NSLock()
        var didFail = false
        func setFailed() {
            failLock.lock(); didFail = true; failLock.unlock()
        }
        func getFailed() -> Bool {
            failLock.lock(); defer { failLock.unlock() }
            return didFail
        }

        // Progress throttle state
        let progressLock = NSLock()
        var lastEmitWall = Date().timeIntervalSinceReferenceDate
        var lastEmitFrame: Int64 = 0
        var lastEmitPTS: CMTime = .zero
        var encodedFrames: Int64 = 0

        func maybeEmitProgress(currentFrame: Int64, outPTS: CMTime) {
            guard durationSeconds > 0 else { return }

            let now = Date().timeIntervalSinceReferenceDate

            progressLock.lock()
            defer { progressLock.unlock() }

            // Throttle: emit at most every 0.25s OR every 12 frames
            let wallDelta = now - lastEmitWall
            let frameDelta = currentFrame - lastEmitFrame
            if wallDelta < 0.25 && frameDelta < 12 { return }

            let secondsDone = CMTimeGetSeconds(outPTS)
            let frac = min(max(secondsDone / durationSeconds, 0.0), 1.0)

            // Rolling fps estimate based on pts delta (better for odd timebases)
            let ptsDelta = CMTimeSubtract(outPTS, lastEmitPTS)
            let secDelta = max(0.0001, CMTimeGetSeconds(ptsDelta))
            let fpsEst = Double(frameDelta) / secDelta

            let eta = (frac > 0.0001) ? (durationSeconds - secondsDone) : nil

            lastEmitWall = now
            lastEmitFrame = currentFrame
            lastEmitPTS = outPTS

            emit(.progress(.init(
                fraction: frac,
                framesDone: Int(currentFrame),
                framesTotal: nil,
                secondsDone: secondsDone,
                secondsTotal: durationSeconds,
                fps: fpsEst.isFinite ? fpsEst : nil,
                etaSeconds: eta,
                bytesWritten: nil,
                message: "Encoding..."
            )))
        }

        let group = DispatchGroup()
        let videoQueue = DispatchQueue(label: "mrencode.engine.video", qos: .userInitiated)
        let audioQueue = DispatchQueue(label: "mrencode.engine.audio", qos: .userInitiated)

        // Ensure group.leave is called once per pump
        let videoDoneLock = NSLock()
        var videoDone = false
        func finishVideoPump() {
            videoDoneLock.lock()
            defer { videoDoneLock.unlock() }
            if videoDone { return }
            videoDone = true
            videoInput.markAsFinished()
            group.leave()
        }

        let audioDoneLock = NSLock()
        var audioDone = false
        func finishAudioPump(_ input: AVAssetWriterInput) {
            audioDoneLock.lock()
            defer { audioDoneLock.unlock() }
            if audioDone { return }
            audioDone = true
            input.markAsFinished()
            group.leave()
        }

        // VIDEO pump

        // MARK: - vImage BGRA -> NV12 (8-bit) -> pack to 10-bit bi-planar (Main10 container)

        func packNV12_8_to_10(dst10: CVPixelBuffer, y8: UnsafePointer<UInt8>, y8RowBytes: Int,
                              uv8: UnsafePointer<UInt8>, uv8RowBytes: Int,
                              width: Int, height: Int) {
            CVPixelBufferLockBaseAddress(dst10, [])
            defer { CVPixelBufferUnlockBaseAddress(dst10, []) }

            // Plane 0: Y (10-bit stored in 16-bit words; we left-shift 8-bit by 2)
            guard let yBase = CVPixelBufferGetBaseAddressOfPlane(dst10, 0) else { return }
            let y10RowBytes = CVPixelBufferGetBytesPerRowOfPlane(dst10, 0)

            // Plane 1: CbCr interleaved (also 16-bit words)
            guard let uvBase = CVPixelBufferGetBaseAddressOfPlane(dst10, 1) else { return }
            let uv10RowBytes = CVPixelBufferGetBytesPerRowOfPlane(dst10, 1)

            for row in 0..<height {
                let srcRow = y8.advanced(by: row * y8RowBytes)
                let dstRow = yBase.advanced(by: row * y10RowBytes).assumingMemoryBound(to: UInt16.self)
                for x in 0..<width {
                    dstRow[x] = UInt16(srcRow[x]) << 8
                }
            }

            let halfH = height / 2
            // NV12 UV row has width bytes (CbCr interleaved, 1 byte each), so 2 bytes per 2x2 luma block.
            for row in 0..<halfH {
                let srcRow = uv8.advanced(by: row * uv8RowBytes)
                let dstRow = uvBase.advanced(by: row * uv10RowBytes).assumingMemoryBound(to: UInt16.self)

                // For each pixel-pair horizontally, we have Cb,Cr (2 bytes) -> two UInt16 words.
                // Total 2 * (width/2) words == width words.
                let words = width
                for i in 0..<words {
                    dstRow[i] = UInt16(srcRow[i]) << 8
                }
            }
        }

        func convertBGRA_to_420_10bit_vImage(srcPB: CVPixelBuffer, dstPB: CVPixelBuffer, width: Int, height: Int) -> Bool {
            CVPixelBufferLockBaseAddress(srcPB, .readOnly)
            defer { CVPixelBufferUnlockBaseAddress(srcPB, .readOnly) }

            guard let srcBase = CVPixelBufferGetBaseAddress(srcPB) else { return false }
            let srcRowBytes = CVPixelBufferGetBytesPerRow(srcPB)

            // Temp 8-bit NV12 planes (Y + interleaved CbCr)
            var yBuf = vImage_Buffer()
            var uvBuf = vImage_Buffer()

            let yInit = vImageBuffer_Init(&yBuf, vImagePixelCount(height), vImagePixelCount(width), 8, vImage_Flags(kvImageNoFlags))
            guard yInit == kvImageNoError else { return false }

            let uvInit = vImageBuffer_Init(&uvBuf, vImagePixelCount(height / 2), vImagePixelCount(width), 8, vImage_Flags(kvImageNoFlags))
            guard uvInit == kvImageNoError else {
                free(yBuf.data)
                return false
            }

            defer {
                free(yBuf.data)
                free(uvBuf.data)
            }

            var src = vImage_Buffer(data: srcBase, height: vImagePixelCount(height), width: vImagePixelCount(width), rowBytes: srcRowBytes)

            // BGRA8888 -> 420Yp8 + CbCr8 (NV12)
            // vImage expects ARGB order. We use a permute map to interpret BGRA as ARGB.
            // permuteMap is interpreted as: [A, R, G, B] indices into the source pixel (BGRA = [B,G,R,A]).
            // So ARGB = [A(3), R(2), G(1), B(0)].
            let permute: [UInt8] = [3, 2, 1, 0]


            // This is an Accelerate-provided conversion (good chroma behavior vs opaque encoder paths).
            // Build vImage conversion info (ARGB -> YpCbCr). BT.709, video-range.
            var pixelRange = vImage_YpCbCrPixelRange(
                Yp_bias: 0,
                CbCr_bias: 128,
                YpRangeMax: 255,
                CbCrRangeMax: 255,
                YpMax: 255,
                YpMin: 0,
                CbCrMax: 255,
                CbCrMin: 0
            )

            var info = vImage_ARGBToYpCbCr()
            let genErr = vImageConvert_ARGBToYpCbCr_GenerateConversion(
                kvImage_ARGBToYpCbCrMatrix_ITU_R_709_2,
                &pixelRange,
                &info,
                kvImageARGB8888,
                kvImage420Yp8_CbCr8,
                vImage_Flags(kvImageNoFlags)
            )
            guard genErr == kvImageNoError else { return false }

            // BGRA8888 -> 420Yp8 + CbCr8 (NV12). We use permuteMap to map BGRA into ARGB ordering.
            let err = vImageConvert_ARGB8888To420Yp8_CbCr8(
                &src,
                &yBuf,
                &uvBuf,
                &info,
                permute,
                vImage_Flags(kvImageNoFlags)
            )


            guard err == kvImageNoError else { return false }

            // Pack 8-bit planes into the 10-bit destination buffer (<<2)
            let y8Ptr = yBuf.data.assumingMemoryBound(to: UInt8.self)
            let uv8Ptr = uvBuf.data.assumingMemoryBound(to: UInt8.self)
            packNV12_8_to_10(dst10: dstPB,
                             y8: y8Ptr, y8RowBytes: yBuf.rowBytes,
                             uv8: uv8Ptr, uv8RowBytes: uvBuf.rowBytes,
                             width: width, height: height)
            return true
        }
        group.enter()
        var frameIndex: Int64 = 0

        videoInput.requestMediaDataWhenReady(on: videoQueue) {
            while videoInput.isReadyForMoreMediaData {

                if cancel() { finishVideoPump(); return }

                guard let sb = videoOutput.copyNextSampleBuffer() else {
                    finishVideoPump(); return
                }
                
                guard let srcPB = CMSampleBufferGetImageBuffer(sb) else {
                    setFailed(); finishVideoPump(); return
                }

                if cancel() { finishVideoPump(); return }

                // Optional GUI overlay / effects hook (operate on BGRA source buffer)
                if needsOverlays, let hook = req.videoFrameHook {
                    let ctx = FrameContext(frameIndex: frameIndex, presentationTime: sb.presentationTimeStamp, nominalFPS: fps)
                    hook(srcPB, ctx)
                }

                // Perceptual conditioning (still operating on source buffer)
                if Double(req.settings.qualityCRF) <= 20.0 {
                    EncodeCore.applyChromaSmoothing(to: srcPB, radius: 0.6)
                }

                // HEVC quality-first: vImage owns BGRA->YCbCr + chroma resampling.
                // We convert to NV12 8-bit, then pack to 10-bit bi-planar (Main10 container).
                // If anything fails, fall back to the source buffer (still encodes, but may look worse on saturated edges).
                let encPB: CVPixelBuffer = {
                    guard req.settings.codec == .hevc,
                          let pool = adaptor.pixelBufferPool
                    else { return srcPB }

                    var dst: CVPixelBuffer?
                    if CVPixelBufferPoolCreatePixelBuffer(kCFAllocatorDefault, pool, &dst) != kCVReturnSuccess {
                        return srcPB
                    }
                    guard let dstPB = dst else { return srcPB }

                    let ok = convertBGRA_to_420_10bit_vImage(
                        srcPB: srcPB,
                        dstPB: dstPB,
                        width: aligned.width,
                        height: aligned.height
                    )
                    return ok ? dstPB : srcPB
                }()


                // NCLC per-frame (apply to the buffer that will be encoded)
                if let triplet = EncodeCore.nclcTripletToApply(settings: req.settings, meta: req.meta) {
                    EncodeCore.applyNCLCToPixelBuffer(encPB, triplet: triplet)
                }

                let outPTS = CMTimeMultiply(frameDur, multiplier: Int32(frameIndex))
                frameIndex += 1
                encodedFrames = frameIndex

                maybeEmitProgress(currentFrame: frameIndex, outPTS: outPTS)

                if cancel() { finishVideoPump(); return }

                if !adaptor.append(encPB, withPresentationTime: outPTS) {
                    setFailed(); finishVideoPump(); return
                }


                if cancel() { finishVideoPump(); return }
            }
        }

        // AUDIO pump
        if let aOut = audioOutput, let aIn = audioInput {
            group.enter()
            aIn.requestMediaDataWhenReady(on: audioQueue) {
                while aIn.isReadyForMoreMediaData {
                    if cancel() { finishAudioPump(aIn); return }

                    guard let sb = aOut.copyNextSampleBuffer() else {
                        finishAudioPump(aIn); return
                    }

                    if cancel() { finishAudioPump(aIn); return }

                    if !aIn.append(sb) {
                        setFailed(); finishAudioPump(aIn); return
                    }

                    if cancel() { finishAudioPump(aIn); return }
                }
            }
        }

        // Wait for pumps
        group.wait()

        if cancel() {
            reader.cancelReading()
            writer.cancelWriting()
            Self.cleanupTemp(tempURL)
            let e = EncodeError(.cancelled, "Encode cancelled.")
            emit(.failed(e))
            return .failure(e)
        }

        if getFailed() || reader.status == .failed || writer.status == .failed {
            reader.cancelReading()
            writer.cancelWriting()
            Self.cleanupTemp(tempURL)
            let msg = writer.error?.localizedDescription
                ?? reader.error?.localizedDescription
                ?? "Unknown encode failure"
            let e = EncodeError(.pipelineFailed, msg)
            emit(.failed(e))
            return .failure(e)
        }

        emit(.phase(.finalizing))

        // Finish writing (synchronous wait via semaphore to return Result)
        let sema = DispatchSemaphore(value: 0)
        var finalResult: Result<EncodeResult, EncodeError> = .failure(.init(.unknown, "Finalization did not run."))

        writer.finishWriting {
            defer { sema.signal() }

            guard writer.status == .completed else {
                Self.cleanupTemp(tempURL) // best-effort remove temp encode

                // NEW: remove empty .mrencode_tmp if applicable
                let tmpDir = tempURL.deletingLastPathComponent()
                if tmpDir.lastPathComponent == ".mrencode_tmp" {
                    Self.cleanupEmptyDir(tmpDir)
                }

                let e = EncodeError(.writerFailed, writer.error?.localizedDescription ?? "Writer did not complete")
                emit(.failed(e))
                finalResult = .failure(e)
                return
            }

            let fm = FileManager.default

            do {
                // Ensure parent directory exists (safe no-op if already exists)
                try fm.createDirectory(
                    at: req.outputURL.deletingLastPathComponent(),
                    withIntermediateDirectories: true
                )

                // Finalize temp → final using unified overwrite + cross-volume logic
                try OutputFinalizer.finalize(
                    tempURL: tempURL,
                    finalURL: req.outputURL,
                    options: .init(allowOverwrite: req.allowOverwrite)
                )

                // At this point tempURL should be gone, but keep a last-resort sweep.
                Self.cleanupTemp(tempURL)

                // NEW: remove empty .mrencode_tmp if applicable
                let tmpDir = tempURL.deletingLastPathComponent()
                if tmpDir.lastPathComponent == ".mrencode_tmp" {
                    Self.cleanupEmptyDir(tmpDir)
                }

                let r = EncodeResult(
                    outputURL: req.outputURL,
                    durationSeconds: durationSeconds > 0 ? durationSeconds : nil,
                    framesEncoded: Int(encodedFrames)
                )
                emit(.completed(r))
                finalResult = .success(r)

            } catch {
                // Best-effort cleanup (do NOT try to chase .sb-* anymore)
                Self.cleanupTemp(tempURL)

                // NEW: remove empty .mrencode_tmp if applicable
                let tmpDir = tempURL.deletingLastPathComponent()
                if tmpDir.lastPathComponent == ".mrencode_tmp" {
                    Self.cleanupEmptyDir(tmpDir)
                }

                let e = EncodeError(.finalizeFailed, "Failed to finalize output: \(error.localizedDescription)")
                emit(.failed(e))
                finalResult = .failure(e)
            }
        }

        sema.wait()
        return finalResult
    }
    
    private static func cleanupTemp(_ url: URL) {
        let fm = FileManager.default
        guard fm.fileExists(atPath: url.path) else { return }
        try? fm.removeItem(at: url)
    }
    
    private static func cleanupEmptyDir(_ dir: URL) {
        let fm = FileManager.default
        guard let items = try? fm.contentsOfDirectory(atPath: dir.path),
              items.isEmpty else { return }
        try? fm.removeItem(at: dir)
    }
}
