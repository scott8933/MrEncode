//
//  EncodeCLI.swift
//  MrEncode
//
//  CLI-path encoder (droplets, batch scripts).  Owns: progress callbacks,
//  cancellation booleans, console output, and the read/write pump.
//  All codec / bitrate / composition / NCLC / filtering logic delegates to EncodeCore.
//

import Foundation
import AVFoundation
import VideoToolbox

enum EncodeCLI {

    /// Progress callback: (elapsedSeconds, percentComplete)
    typealias ProgressCallback   = (Double, Double) -> Void

    /// Cancellation check — return true to abort
    typealias CancellationCheck  = () -> Bool

    /// Encode a single item.  Returns true on success.
    static func encodeItem(
        _ item:            MediaItem,
        output:            URL,
        settings:          Settings,
        progressCallback:  ProgressCallback?  = nil,
        cancellationCheck: CancellationCheck? = nil
    ) -> Bool {

        let startTime = Date()

        // ─── Output directory ────────────────────────────────────────────────
        let outputDir = output.deletingLastPathComponent()
        do {
            try FileManager.default.createDirectory(at: outputDir, withIntermediateDirectories: true)
        } catch {
            print("  ✗ Failed to create output directory: \(error)")
            return false
        }

        let tempURL = outputDir.appendingPathComponent(".tmp-\(UUID().uuidString)-\(output.lastPathComponent)")

        func cleanupTemp() {
            if FileManager.default.fileExists(atPath: tempURL.path) {
                do    { try FileManager.default.removeItem(at: tempURL) }
                catch { print("  ⚠️ Failed to remove temp file: \(error)") }
            }
        }

        // ─── Asset & track setup ─────────────────────────────────────────────
        let asset = AVAsset(url: item.url)
        guard let videoTrack = asset.tracks(withMediaType: .video).first else {
            print("  ✗ No video track found"); cleanupTemp(); return false
        }

        let frameDur      = EncodeCore.snappedFrameDuration(for: videoTrack)
        let fps           = EncodeCore.snappedFPS(for: videoTrack)
        let totalDuration = item.meta.durationSeconds > 0
            ? item.meta.durationSeconds
            : CMTimeGetSeconds(asset.duration)

        let target  = EncodeCore.computeTargetDimensions(videoTrack: videoTrack, settings: settings)
        let aligned = EncodeCore.alignDimensions(target)

        print("  Encoding: \(target.width)×\(target.height) → \(aligned.width)×\(aligned.height)")
        print("  Duration: \(totalDuration)s, FPS: \(fps)")

        // ─── Reader ──────────────────────────────────────────────────────────
        let reader: AVAssetReader
        do { reader = try AVAssetReader(asset: asset) }
        catch { print("  ✗ Failed to create reader: \(error)"); cleanupTemp(); return false }

        let videoComposition = EncodeCore.makeVideoComposition(
            track: videoTrack, contentSize: target, renderSize: aligned, settings: settings)

        let videoOutput = AVAssetReaderVideoCompositionOutput(
            videoTracks: [videoTrack],
            videoSettings: [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
        )
        videoOutput.videoComposition       = videoComposition
        videoOutput.alwaysCopiesSampleData = false
        reader.add(videoOutput)

        // Audio reader
        let audioTrack  = asset.tracks(withMediaType: .audio).first
        var audioOutput: AVAssetReaderOutput?
        if let at = audioTrack {
            let ao = AVAssetReaderTrackOutput(track: at, outputSettings: EncodeCore.audioReaderSettings)
            ao.alwaysCopiesSampleData = false
            reader.add(ao)
            audioOutput = ao
        }

        // ─── Writer ──────────────────────────────────────────────────────────
        let writer: AVAssetWriter
        do {
            let fileType: AVFileType = (settings.containerFormat == .mp4) ? .mp4 : .mov
            writer = try AVAssetWriter(outputURL: tempURL, fileType: fileType)
        } catch {
            print("  ✗ Failed to create writer: \(error)"); cleanupTemp(); return false
        }

        writer.movieTimeScale          = (frameDur.timescale > 1000) ? frameDur.timescale : CMTimeScale(60000)
        writer.shouldOptimizeForNetworkUse = true

        // Video input — base settings from Engine, then layer NCLC container tags on top
        var vidSettings = EncodeCore.videoInputSettings(
            settings: settings, width: aligned.width, height: aligned.height, fps: fps)

        if let triplet = EncodeCore.nclcTripletToApply(settings: settings, meta: item.meta) {
            vidSettings[AVVideoColorPropertiesKey] = EncodeCore.nclcToAVVideoColorProperties(triplet: triplet)
        }

        let videoInput = AVAssetWriterInput(mediaType: .video, outputSettings: vidSettings)
        videoInput.expectsMediaDataInRealTime = false
        videoInput.mediaTimeScale = frameDur.timescale
        videoInput.transform      = .identity
        writer.add(videoInput)

        let adaptor = AVAssetWriterInputPixelBufferAdaptor(
            assetWriterInput: videoInput,
            sourcePixelBufferAttributes: [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                kCVPixelBufferWidthKey  as String: aligned.width,
                kCVPixelBufferHeightKey as String: aligned.height
            ]
        )

        // Audio input
        var audioInput: AVAssetWriterInput?
        if audioTrack != nil {
            let ai = AVAssetWriterInput(mediaType: .audio, outputSettings: EncodeCore.audioOutputSettings)
            ai.expectsMediaDataInRealTime = false
            writer.add(ai)
            audioInput = ai
        }

        // ─── Start I/O ───────────────────────────────────────────────────────
        guard writer.startWriting() else {
            print("  ✗ Writer failed to start: \(writer.error?.localizedDescription ?? "unknown")")
            cleanupTemp(); return false
        }
        guard reader.startReading() else {
            print("  ✗ Reader failed to start: \(reader.error?.localizedDescription ?? "unknown")")
            cleanupTemp(); return false
        }
        writer.startSession(atSourceTime: .zero)

        let group      = DispatchGroup()
        let videoQueue = DispatchQueue(label: "cli.video", qos: .userInitiated)
        let audioQueue = DispatchQueue(label: "cli.audio", qos: .userInitiated)

        var frameIndex: Int64         = 0
        var wasCancelled              = false
        var lastProgressUpdate        = Date.distantPast
        let progressInterval: TimeInterval = 0.5

        // ─── VIDEO pump ──────────────────────────────────────────────────────
        group.enter()
        videoInput.requestMediaDataWhenReady(on: videoQueue) {
            while videoInput.isReadyForMoreMediaData {
                if let check = cancellationCheck, check() {
                    print("  ⚠️ Cancellation detected")
                    wasCancelled = true; videoInput.markAsFinished(); group.leave(); return
                }

                guard let sb = videoOutput.copyNextSampleBuffer(),
                      let pb = CMSampleBufferGetImageBuffer(sb) else {
                    videoInput.markAsFinished(); group.leave(); return
                }

                // NCLC per-frame
                if let triplet = EncodeCore.nclcTripletToApply(settings: settings, meta: item.meta) {
                    EncodeCore.applyNCLCToPixelBuffer(pb, triplet: triplet)
                }

                // Perceptual conditioning — same threshold and radius as GUI path
                if Double(settings.qualityCRF) <= 22.0 {
                    EncodeCore.applyChromaSmoothing(to: pb, radius: 0.6)
                }

                let outPTS = CMTimeMultiply(frameDur, multiplier: Int32(frameIndex))
                frameIndex += 1

                // Throttled progress callback
                if totalDuration > 0, Date().timeIntervalSince(lastProgressUpdate) >= progressInterval {
                    lastProgressUpdate = Date()
                    let elapsed = CMTimeGetSeconds(outPTS)
                    let pct     = min(max(elapsed / totalDuration, 0.0), 1.0)
                    DispatchQueue.main.async { progressCallback?(elapsed, pct) }
                }

                if !adaptor.append(pb, withPresentationTime: outPTS) {
                    videoInput.markAsFinished(); group.leave(); return
                }
            }
        }

        // ─── AUDIO pump ──────────────────────────────────────────────────────
        if let audioOutput = audioOutput, let audioInput = audioInput {
            group.enter()
            audioInput.requestMediaDataWhenReady(on: audioQueue) {
                while audioInput.isReadyForMoreMediaData {
                    if let check = cancellationCheck, check() {
                        wasCancelled = true; audioInput.markAsFinished(); group.leave(); return
                    }
                    guard let sb = audioOutput.copyNextSampleBuffer() else {
                        audioInput.markAsFinished(); group.leave(); return
                    }
                    if !audioInput.append(sb) {
                        audioInput.markAsFinished(); group.leave(); return
                    }
                }
            }
        }

        // ─── Wait & finish ───────────────────────────────────────────────────
        group.wait()

        if wasCancelled {
            print("  ⚠️ Encode was cancelled, cleaning up...")
            reader.cancelReading()
            writer.cancelWriting()
            cleanupTemp()
            return false
        }

        videoInput.markAsFinished()
        audioInput?.markAsFinished()

        let semaphore    = DispatchSemaphore(value: 0)
        var writeSuccess = false

        writer.finishWriting {
            writeSuccess = (writer.status == .completed)
            semaphore.signal()
        }
        semaphore.wait()

        guard writeSuccess else {
            print("  ✗ Writer did not complete: \(writer.error?.localizedDescription ?? "unknown")")
            cleanupTemp(); return false
        }

        // ─── Finalise ────────────────────────────────────────────────────────
        do {
            try? FileManager.default.removeItem(at: output)
            try FileManager.default.moveItem(at: tempURL, to: output)

            let elapsed = Date().timeIntervalSince(startTime)
            print("  ✓ Complete in \(Int(elapsed) / 60)m \(Int(elapsed) % 60)s")
            return true
        } catch {
            print("  ✗ Failed to finalize output: \(error)")
            cleanupTemp()
            return false
        }
    }
}
