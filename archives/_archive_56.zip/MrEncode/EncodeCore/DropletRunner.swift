//
//  DropletRunner.swift
//  MrEncode
//
//  Created by Scott Ulrich on 9/19/25.
//


import Foundation
import AppKit

/// Handles CLI droplet execution and shared droplet validation logic.
struct DropletRunner {
    static func run(arguments: [String]) -> Int {
        
        // Centralized flag parsing (single source of truth)
        let flags = RuntimeFlags.parse(arguments)
        let quiet = flags.quiet
        let suppressChime = flags.suppressChime
        
        let progressMode = parseProgressMode(arguments)
        let progressFileURL = parseProgressFileURL(arguments)
        let progressPrinter = CLIProgressPrinter(mode: progressMode, progressFileURL: progressFileURL)

        // Handle help
        if arguments.contains("--help") || arguments.contains("-h") {
            printCLIHelp()
            return 0
        }

        // Handle droplet CLI (supports both legacy --preset-file and new --droplet flags)
        if let result = parsePathArgument(arguments, flag: "--preset-file") {
            let videoFilePaths = collectMediaPaths(from: arguments, startingAt: result.nextIndex)
            return runDropletCLI(
                dropletFile: result.path,
                videoFiles: videoFilePaths,
                quiet: quiet,
                suppressChime: suppressChime,
                progressPrinter: progressPrinter
            )
        }

        if let result = parsePathArgument(arguments, flag: "--droplet") {
            let videoFilePaths = collectMediaPaths(from: arguments, startingAt: result.nextIndex)
            return runDropletCLI(
                dropletFile: result.path,
                videoFiles: videoFilePaths,
                quiet: quiet,
                suppressChime: suppressChime,
                progressPrinter: progressPrinter
            )
        }

        print("Error: No valid CLI command found. Use --help for usage information.")
        return 1
    }


    // MARK: - Droplet CLI
    
    private static func ensureAppKitInitialized() {
        _ = NSApplication.shared
    }

    private static func fireDoneChimeIfAllowed(suppressChime: Bool) {
        guard !suppressChime else { return }
        Task { @MainActor in
            SoundManager.shared.playDoneChime()
        }
    }

    /// Gives the main runloop a brief chance to execute scheduled @MainActor work.
    /// Use this only for the "quiet + chime-only" case.
    private static func pumpMainRunLoop(seconds: TimeInterval) {
        let until = Date().addingTimeInterval(seconds)
        RunLoop.main.run(until: until)
    }


    private static func runDropletCLI(
        dropletFile: String,
        videoFiles: [String],
        quiet: Bool,
        suppressChime: Bool,
        progressPrinter: CLIProgressPrinter
    ) -> Int
    {
        print("Running droplet: \(dropletFile)")
        print("Video files: \(videoFiles)")

        // Load droplet settings
        guard let dropletData = try? Data(contentsOf: URL(fileURLWithPath: dropletFile)),
              let droplet = try? JSONDecoder().decode(DropletFile.self, from: dropletData) else {
            print("Error: Could not load droplet file: \(dropletFile)")

            showCLIErrorDialog(
                title: "Invalid Droplet",
                message: "Could not load droplet settings",
                detail: "The droplet file appears to be corrupted or from an incompatible version of MrEncode.\n\nDroplet file: \(dropletFile)",
                quiet: quiet
            )
            return 1
        }

        print("Loaded preset: \(droplet.presetName)")

        // Convert paths to URLs and process through QueueImportService (handles folders, filtering, etc.)
        let inputURLs = videoFiles.map { URL(fileURLWithPath: $0) }
        let importResult = QueueImportService.process(inputURLs)

        // Show warnings if any (folder scan messages)
        if !importResult.warnings.isEmpty && !quiet {
            let warningMessage = importResult.warnings.joined(separator: "\n\n")
            print("Warnings during import:")
            print(warningMessage)
            
            showCLIErrorDialog(
                title: "Import Warnings",
                message: "Some items were skipped during folder scan",
                detail: warningMessage,
                quiet: false  // Always show warnings even in quiet mode
            )
        }

        // Show rejected files message (non-modal, just print to console)
        if !importResult.rejectedFilenames.isEmpty {
            let list = importResult.rejectedFilenames.count > 5
                ? importResult.rejectedFilenames.prefix(5).joined(separator: ", ")
                    + ", and \(importResult.rejectedFilenames.count - 5) more"
                : importResult.rejectedFilenames.joined(separator: ", ")
            
            print("Skipped unsupported media: \(list)")
        }

        // Check if we need user confirmation (>25 files)
        if importResult.requiresConfirm && !quiet {
            let count = importResult.candidates.count
            let alert = NSAlert()
            alert.messageText = "Process \(count) Files?"
            alert.informativeText = "You are about to process \(count) video files. This may take a significant amount of time.\n\nDo you want to continue?"
            alert.alertStyle = .warning
            alert.addButton(withTitle: "Process All")
            alert.addButton(withTitle: "Cancel")

            ensureAppKitInitialized()
            let app = NSApplication.shared
            app.setActivationPolicy(.regular)
            app.activate(ignoringOtherApps: true)
            
            let response = alert.runModal()
            
            app.setActivationPolicy(.accessory)
            
            if response != .alertFirstButtonReturn {
                print("User cancelled processing of \(count) files")
                return 0  // User cancelled, exit cleanly
            }
        }

        guard !importResult.candidates.isEmpty else {
            print("Error: No supported video files found")

            let fileList = videoFiles.map { URL(fileURLWithPath: $0).lastPathComponent }.joined(separator: ", ")
            showCLIErrorDialog(
                title: "No Supported Files",
                message: "No supported video files found",
                detail: "No supported video files were found.\n\nFiles/folders provided: \(fileList.isEmpty ? "None" : fileList)",                quiet: quiet
            )
            return 1
        }

        print("Processing \(importResult.candidates.count) video file(s)...")

        // Process each file - collect results WITHOUT showing individual alerts
        var successCount = 0
        var failureCount = 0
        var errors: [(file: String, error: DropletError)] = []
        var submittedJobIDs: [String] = []
        var cancelCount = 0
        
        progressPrinter.sink(.phase(.preparing))

        let results = processFiles(
            importResult.candidates,
            settings: droplet.settings,
            dropletFileURL: URL(fileURLWithPath: dropletFile),
            emit: { ev in progressPrinter.sink(ev) }
        ) { _, jobID in
            guard !jobID.isEmpty else { return }
            submittedJobIDs.append(jobID)
            print("  Submitted as job: \(jobID)")
        }

        for (index, entry) in results.enumerated() {
            let fileURL = entry.url
            print("[\(index + 1)/\(results.count)] Processing: \(fileURL.lastPathComponent)")

            switch entry.result {
            case .success:
                successCount += 1
                print("  ✓ Complete")
            case .failure(let error):
                if case .cancelled = error {
                    cancelCount += 1
                    print("  ⚠ Cancelled by user")
                } else {
                    failureCount += 1
                    errors.append((fileURL.lastPathComponent, error))
                    print("  ✗ Failed: \(error.message)")
                }
            }
        }

        // Show final summary - SINGLE consolidated alert
        DropletRunner.ensureAppKitInitialized()

        print("\nDroplet processing complete.")
        print("Successful: \(successCount)")
        print("Failed: \(failureCount)")

        if failureCount > 0 {
            let failedList = errors
                .map { "• \($0.file): \($0.error.message)" }
                .joined(separator: "\n")

            let errorSummary =
                "Processing completed with some failures.\n\n" +
                "Successful: \(successCount) file\(successCount == 1 ? "" : "s")\n" +
                "Failed: \(failureCount) file\(failureCount == 1 ? "" : "s")\n\n" +
                "Failed files:\n\(failedList)"

            DropletRunner.fireDoneChimeIfAllowed(suppressChime: suppressChime)

            if !quiet {
                showCLIErrorDialog(
                    title: "Processing Complete with Errors",
                    message: "Some files could not be processed",
                    detail: errorSummary,
                    quiet: quiet
                )
            } else if !suppressChime {
                DropletRunner.pumpMainRunLoop(seconds: 0.35)
            }

        } else if successCount > 0 {

            DropletRunner.fireDoneChimeIfAllowed(suppressChime: suppressChime)

            if !quiet {
                let alert = NSAlert()
                alert.messageText = "Processing Complete"
                alert.informativeText =
                    "Successfully processed \(successCount) file\(successCount == 1 ? "" : "s") using the '\(droplet.presetName)' preset."
                alert.alertStyle = .informational
                alert.addButton(withTitle: "OK")

                let app = NSApplication.shared
                app.setActivationPolicy(.regular)
                app.activate(ignoringOtherApps: true)
                alert.runModal()
                app.setActivationPolicy(.accessory)

            } else if !suppressChime {
                DropletRunner.pumpMainRunLoop(seconds: 0.35)
            }

        }

        return failureCount > 0 ? 1 : 0
    }

    /// Processes a single media file with the provided settings.
    /// Returns a `Result` so CLI and GUI wrappers can report failures differently and unit tests
    /// can cover each error scenario without depending on alerts.
    static func processFile(
        fileURL: URL,
        settings: Settings,
        dropletFileURL: URL,
        emit: @escaping EncodeEventSink,
        jobIDSink: ((String) -> Void)? = nil
    ) -> Result<Void, DropletError> {

        // Probe metadata (your existing path)
        let meta = MetadataExtractor.extract(for: fileURL)
        let item = MediaItem(url: fileURL, meta: meta, status: .queued)

        // Output naming (your existing path)
        let outputURL = OutputNamer.suggestedOutputURL(for: fileURL, settings: settings)

        // Validate (your existing path)
        switch validateFileForProcessing(item: item, settings: settings) {
        case .success:
            break
        case .failure(let error):
            emit(.failed(.init(.invalidInput, error.message))) // best-effort signal for CLI/Deadline
            return .failure(error)
        }

        // Helpful per-file header
        emit(.phase(.preparing))
        emit(.warning("Input: \(fileURL.lastPathComponent)"))

        switch settings.runMode {

        case .localNative:
            emit(.phase(.preparing))
            emit(.warning("Encoding (local): \(fileURL.lastPathComponent)"))

            // Optional: warn once that this is native VT now (keeps logs accurate while enum is stale)
            emit(.warning("MODE: Local (native AVFoundation/VideoToolbox)"))

            // Cancellation: if you later add SIGINT/global cancel in CLI, plug it in here.
            let cancel: CancelCheck = { false }

            // No overlays in CLI currently. If you ever want CLI burn-ins, we can add a hook here.
            let request = EncodeRequest(
                inputURL: fileURL,
                outputURL: outputURL,
                allowOverwrite: true, // If droplets have an overwrite flag, pass it through here.
                settings: settings,
                meta: meta,
                filenameForOverlay: fileURL.lastPathComponent,
                videoFrameHook: nil
            )

            let engineResult = EncodeEngine.encode(
                request,
                cancel: cancel,
                emit: emit
            )

            switch engineResult {
            case .success:
                return .success(())

            case .failure(let e):
                if e.code == .cancelled {
                    return .failure(.cancelled(message: e.message))
                } else {
                    return .failure(.encodeFailed(message: e.message))
                }
            }


        case .remoteDeadline:
            emit(.phase(.preparing))
            emit(.warning("Submitting (Deadline): \(fileURL.lastPathComponent)"))

            return runRemoteEncodeCLI(
                item: item,
                output: outputURL,
                settings: settings,
                dropletFileURL: dropletFileURL,
                jobIDSink: jobIDSink
            )
        }
    }


    /// Convenience batch helper used by CLI/GUI wrappers and unit tests.
    static func processFiles(
        _ fileURLs: [URL],
        settings: Settings,
        dropletFileURL: URL,
        emit: @escaping EncodeEventSink,
        jobIDSink: ((URL, String) -> Void)? = nil
    ) -> [(url: URL, result: Result<Void, DropletError>)] {

        fileURLs.map { url in
            // Optional per-file boundary event (useful for CLI/Deadline logs)
            emit(.warning("Processing: \(url.lastPathComponent)"))

            let result = processFile(
                fileURL: url,
                settings: settings,
                dropletFileURL: dropletFileURL,
                emit: emit,
                jobIDSink: { jobID in jobIDSink?(url, jobID) }
            )
            return (url, result)
        }
    }

    
    
    // MARK: - Parsing Helpers
    
    private static func collectMediaPaths(from arguments: [String], startingAt index: Int) -> [String] {
        var paths: [String] = []
        var i = index

        while i < arguments.count {
            let arg = arguments[i]

            // Skip any flag that consumes the next argument (flag + value)
            if RuntimeFlags.flagsWithValue.contains(arg) {
                i += 2
                continue
            }

            // Skip any other flags (boolean switches, unknown flags, etc.)
            if arg.hasPrefix("-") {
                i += 1
                continue
            }

            // Positional argument -> treat as a candidate media path
            paths.append(arg)
            i += 1
        }

        return paths
    }


    // MARK: - Validation

    private static func validateFileForProcessing(item: MediaItem, settings: Settings) -> Result<Void, DropletError> {
        let url = item.url

        guard FileManager.default.fileExists(atPath: url.path) else {
            return .failure(.validation(message: "File does not exist or is not accessible."))
        }

        guard FileManager.default.isReadableFile(atPath: url.path) else {
            return .failure(.validation(message: "File exists but cannot be read. Check file permissions."))
        }

        // Capability-based probe, same as main app - no extension gating
        let probe = MediaProbeService.probeVideoDecode(url)
        if !probe.hasVideo {
            return .failure(.validation(message: "No video track found in \(url.lastPathComponent)"))
        }
        if !probe.canDecode {
            return .failure(.validation(message: "AVFoundation cannot decode \(url.lastPathComponent). The codec may not be supported on this system."))
        }

        if settings.runMode == .remoteDeadline {
            if case .failure(let error) = EncodeRenderfarm.isInputPathAcceptableForFarm(url) {
                return .failure(.validation(message: "Remote encoding error: \(error.message)\n\nFor Deadline rendering, files must be on shared network storage (e.g., /Volumes/Share/...), not local folders like Desktop or Downloads."))
            }

            let pool = settings.pool.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            let group = settings.group.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()

            if pool.isEmpty || pool == "none" {
                return .failure(.validation(message: "Remote encoding error: Deadline pool is not configured.\n\nThis droplet was created for Deadline rendering but the pool setting is missing or set to 'none'."))
            }

            if group.isEmpty || group == "none" {
                return .failure(.validation(message: "Remote encoding error: Deadline group is not configured.\n\nThis droplet was created for Deadline rendering but the group setting is missing or set to 'none'."))
            }
        }

        let compressionInactive = settings.bypassHEVC &&
            settings.scale == .oneToOne &&
            settings.outputSuffix.trimmed.isEmpty

        let nclcInactive = settings.nclcTag.trimmed.lowercased() == "no change" &&
            settings.nclcFilenameLabel.trimmed.isEmpty

        let overlaysInactive = !(settings.burnInFrames || settings.burnInTimecode || settings.burnInFilename)

        if compressionInactive && nclcInactive && overlaysInactive {
            return .failure(.validation(message: "Configuration error: No processing operations are enabled.\n\nThis droplet is configured to bypass compression, skip color tagging, and has no overlays enabled. Nothing would be changed."))
        }

        let allSuffixesBlank = settings.outputSuffix.trimmed.isEmpty &&
            settings.nclcFilenameLabel.trimmed.isEmpty &&
            settings.scaleSuffix.trimmed.isEmpty

        if allSuffixesBlank {
            return .failure(.validation(message: "Configuration error: Output filename would be identical to input.\n\nThis droplet has no filename suffixes configured, so the output would overwrite the original file."))
        }

        return .success(())
    }
    
    
    // MARK: - CLI Helpers
    
    private static func parseStringFlag(_ args: [String], flag: String) -> String? {
        guard let i = args.firstIndex(of: flag), i + 1 < args.count else { return nil }
        return args[i + 1]
    }

    private static func parseProgressMode(_ args: [String]) -> CLIProgressPrinter.Mode {
        if let s = parseStringFlag(args, flag: "--progress")?.lowercased() {
            switch s {
            case "human": return .human
            case "json":  return .json
            case "none":  return .none
            default: break
            }
        }
        // Default: human when attached to a terminal; json otherwise (droplet/farm safer)
        return isatty(fileno(stdout)) != 0 ? .human : .json
    }

    private static func parseProgressFileURL(_ args: [String]) -> URL? {
        guard let s = parseStringFlag(args, flag: "--progress-file") else { return nil }
        return URL(fileURLWithPath: s)
    }



    
    // MARK: - Execution Helpers

    static func runLocalEncodeCLI(
        item: MediaItem,
        output: URL,
        settings: Settings,
        emit: @escaping EncodeEventSink
    ) -> Result<Void, DropletError> {

        let request = EncodeRequest(
            inputURL: item.url,
            outputURL: output,
            allowOverwrite: true,
            settings: settings,
            meta: item.meta,
            filenameForOverlay: item.url.lastPathComponent,
            videoFrameHook: nil
        )

        let r = EncodeEngine.encode(request, cancel: { false }, emit: emit)

        switch r {
        case .success:
            return .success(())
        case .failure(let e):
            if e.code == .cancelled { return .failure(.cancelled(message: e.message)) }
            return .failure(.encodeFailed(message: e.message))
        }
    }


    /// The `dropletFileURL` is the original .mrhevc file from the command line.
        /// It already contains the serialised Settings and is already on whatever
        /// path the user invoked — no need to write or copy a temp preset.
        private static func runRemoteEncodeCLI(item: MediaItem,
                                               output: URL,
                                               settings: Settings,
                                               dropletFileURL: URL,
                                               jobIDSink: ((String) -> Void)? = nil) -> Result<Void, DropletError> {
            let deadlineCmd = settings.deadlineCommandPath.isEmpty
                ? (EncodeRenderfarm.detectDeadlineCommand() ?? "/Applications/Thinkbox/Deadline10/Resources/deadlinecommand")
                : settings.deadlineCommandPath

            guard FileManager.default.isExecutableFile(atPath: deadlineCmd) else {
                return .failure(.deadlineFailed(
                    message: "Deadline command not found at: \(deadlineCmd)\n\n"
                           + "This droplet was created for Deadline rendering, but Deadline "
                           + "is not installed or not accessible on this machine."))
            }

            print("  Submitting to Deadline…")

            let result = EncodeRenderfarm.submitShellJob(
                deadlineCmd: deadlineCmd,
                presetURL:   dropletFileURL,
                input:       item.url,
                output:      output,
                settings:    settings)

            if result.exitCode == 0 {
                if let jid = result.jobID, !jid.isEmpty {
                    jobIDSink?(jid)
                }
                return .success(())
            } else {
                let detail = "Deadline submission failed with exit code \(result.exitCode).\n\n"
                           + "Deadline output:\n\(result.rawOutput.prefix(500))"
                return .failure(.deadlineFailed(message: detail))
            }
        }

    // MARK: - Error Presentation

    private static func presentCLI(error: DropletError, fileName: String, quiet: Bool) {
        print("  \(error.title): \(error.message)")
        let message: String
        switch error {
        case .cancelled:
            message = "Cancelled: \(fileName)"
        default:
            message = "Cannot process \(fileName)"
        }
        showCLIErrorDialog(
            title: error.title,
            message: message,
            detail: error.message,
            quiet: quiet
        )
    }

    @MainActor static func presentGUI(error: DropletError, fileURL: URL, state: AppState) {
        state.pushMessage(
            level: error.logLevel,
            "Droplet: \(error.title) — \(fileURL.lastPathComponent)",
            filename: fileURL.lastPathComponent,
            code: error.logCode,
            originKey: "droplet-gui",
            detail: error.message
        )
    }

    private static func showCLIErrorDialog(title: String, message: String, detail: String, quiet: Bool) {
        guard !quiet else { return }

        let present = {
            let alert = NSAlert()
            alert.messageText = title
            alert.informativeText = "\(message)\n\n\(detail)"
            alert.alertStyle = .critical
            alert.addButton(withTitle: "OK")

            let app = NSApplication.shared
            app.setActivationPolicy(.regular)
            
            // Force the app to front
            NSRunningApplication.current.activate(options: [.activateAllWindows, .activateIgnoringOtherApps])
            
            alert.runModal()

            app.setActivationPolicy(.accessory)
        }

        if Thread.isMainThread {
            present()
        } else {
            DispatchQueue.main.sync {
                present()
            }
        }
    }



    // MARK: - Utilities

    private static func parsePathArgument(_ arguments: [String], flag: String) -> (nextIndex: Int, path: String)? {
        for (index, arg) in arguments.enumerated() {
            if arg == flag {
                if index + 1 < arguments.count {
                    return (index + 2, arguments[index + 1])
                }
            } else if arg.hasPrefix(flag + "=") {
                let path = String(arg.dropFirst(flag.count + 1))
                return (index + 1, path)
            }
        }
        return nil
    }

    private static func extractJobID(from output: String) -> String? {
        if let match = output.range(of: #"\[([0-9a-f]{24})\]"#, options: .regularExpression) {
            return String(output[match]).trimmingCharacters(in: CharacterSet(charactersIn: "[]"))
        }
        return nil
    }

    private static func printCLIHelp() {
        print("""
MrEncode Command Line Interface

Usage:
  MrEncode --cli --droplet <preset.json> <file1> [file2] ...
  MrEncode --help

Options:
  --cli                 Run in CLI mode (no GUI)
  --droplet <file>      Use droplet preset file
  --quiet, -quiet       Suppress status popups (NSAlert dialogs)
  --mute, -mute         Suppress audio chime on finish
  --help, -h            Show this help message

Examples:
  # Process video files with a droplet preset
  MrEncode --cli --droplet MyPreset.json video1.mov video2.mp4

  # For GUI droplet mode (current behavior)
  MrEncode --droplet MyPreset.json video1.mov video2.mp4

Supported Formats:
  Any video format that can be decoded by macOS VideoToolbox
  (QuickTime .mov, MP4, M4V, and most modern video codecs)

Encoding Backend:
  Local mode uses native VideoToolbox (no external dependencies)
  Remote mode uses Deadline render farm with FFmpeg plugin
""")
    }
}

private extension String {
    var trimmed: String { trimmingCharacters(in: .whitespacesAndNewlines) }
}
