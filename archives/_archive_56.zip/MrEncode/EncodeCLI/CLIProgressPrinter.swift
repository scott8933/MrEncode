//
//  CLIProgressPrinter.swift
//  MrEncode
//
//  Created by scott ulrich on 2/2/26.
//


import Foundation

final class CLIProgressPrinter {
    enum Mode {
        case human
        case json
        case none
    }

    private let mode: Mode
    private let fileHandle: FileHandle?
    private var lastHumanLineLen: Int = 0
    private var lastEmitWall: TimeInterval = 0

    init(mode: Mode, progressFileURL: URL?) {
        self.mode = mode
        if let url = progressFileURL {
            FileManager.default.createFile(atPath: url.path, contents: nil)
            self.fileHandle = try? FileHandle(forWritingTo: url)
            self.fileHandle?.seekToEndOfFile()
        } else {
            self.fileHandle = nil
        }
    }

    deinit {
        try? fileHandle?.close()
    }

    func sink(_ ev: EncodeEvent) {
        switch mode {
        case .none:
            break
        case .human:
            printHuman(ev)
        case .json:
            printJSONLine(ev)
        }

        if fileHandle != nil {
            writeJSONLineToFile(ev)
        }
    }

    // MARK: - Human

    private func printHuman(_ ev: EncodeEvent) {
        switch ev {
        case .phase(let p):
            writeHumanLine("Phase: \(p.rawValue)")
        case .warning(let s):
            writeHumanLine("Warning: \(s)")
        case .progress(let pr):
            let pct = Int((pr.fraction * 100.0).rounded())
            var parts: [String] = ["\(pct)%"]
            if let fps = pr.fps { parts.append(String(format: "%.1f fps", fps)) }
            if let eta = pr.etaSeconds { parts.append("ETA \(formatETA(eta))") }
            if let msg = pr.message, !msg.isEmpty { parts.append(msg) }
            writeHumanLine(parts.joined(separator: "  "))
        case .completed(let r):
            writeHumanLine("Done: \(r.outputURL.path)")
        case .failed(let e):
            writeHumanLine("Failed: \(e.message)")
        }
    }

    private func writeHumanLine(_ line: String) {
        // Single-line overwrite
        let padCount = max(0, lastHumanLineLen - line.count)
        let padded = line + String(repeating: " ", count: padCount)
        FileHandle.standardOutput.write(( "\r" + padded ).data(using: .utf8)!)
        FileHandle.standardOutput.synchronizeFile()
        lastHumanLineLen = line.count
    }

    private func formatETA(_ seconds: Double) -> String {
        let s = max(0, Int(seconds.rounded()))
        let m = s / 60
        let r = s % 60
        return String(format: "%d:%02d", m, r)
    }

    // MARK: - JSON lines

    private func printJSONLine(_ ev: EncodeEvent) {
        guard let data = encodeJSONLine(ev) else { return }
        FileHandle.standardOutput.write(data)
        FileHandle.standardOutput.write("\n".data(using: .utf8)!)
    }

    private func writeJSONLineToFile(_ ev: EncodeEvent) {
        guard let fh = fileHandle else { return }
        guard let data = encodeJSONLine(ev) else { return }
        fh.write(data)
        fh.write("\n".data(using: .utf8)!)
        fh.synchronizeFile()
    }

    private func encodeJSONLine(_ ev: EncodeEvent) -> Data? {
        var obj: [String: Any] = ["ts": Date().timeIntervalSince1970]

        switch ev {
        case .phase(let p):
            obj["type"] = "phase"
            obj["value"] = p.rawValue

        case .warning(let s):
            obj["type"] = "warning"
            obj["message"] = s

        case .progress(let pr):
            obj["type"] = "progress"
            obj["fraction"] = pr.fraction
            if let v = pr.framesDone { obj["framesDone"] = v }
            if let v = pr.framesTotal { obj["framesTotal"] = v }
            if let v = pr.secondsDone { obj["secDone"] = v }
            if let v = pr.secondsTotal { obj["secTotal"] = v }
            if let v = pr.fps { obj["fps"] = v }
            if let v = pr.etaSeconds { obj["eta"] = v }
            if let v = pr.bytesWritten { obj["bytes"] = v }
            if let v = pr.message { obj["message"] = v }

        case .completed(let r):
            obj["type"] = "completed"
            obj["output"] = r.outputURL.path
            if let d = r.durationSeconds { obj["duration"] = d }
            if let f = r.framesEncoded { obj["frames"] = f }

        case .failed(let e):
            obj["type"] = "failed"
            obj["code"] = e.code.rawValue
            obj["message"] = e.message
        }

        return try? JSONSerialization.data(withJSONObject: obj, options: [])
    }
}
