//
//  CLIEncoder.swift
//  MrEncode
//

import Foundation
import AVFoundation
import VideoToolbox

enum CLIEncoder {
    
    /// Progress callback: (elapsedSeconds, percentComplete)
    typealias ProgressCallback = (Double, Double) -> Void
    
    /// Cancellation check callback - return true to cancel
    typealias CancellationCheck = () -> Bool
    
    /// Encode a single item in CLI mode with progress reporting and cancellation support
    /// Returns true on success, false on failure/cancellation
    static func encodeItem(
        _ item: MediaItem,
        output: URL,
        settings: Settings,
        progressCallback: ProgressCallback? = nil,
        cancellationCheck: CancellationCheck? = nil
    ) -> Bool {
        
        let startTime = Date()
        
        // Ensure output directory exists
        let outputDir = output.deletingLastPathComponent()
        do {
            try FileManager.default.createDirectory(at: outputDir, withIntermediateDirectories: true)
        } catch {
            print("  ✗ Failed to create output directory: \(error)")
            return false
        }
        
        // Create temp output URL
        let tempURL = outputDir.appendingPathComponent(".tmp-\(UUID().uuidString)-\(output.lastPathComponent)")
        
        // Helper to clean up temp file
        func cleanupTemp() {
            if FileManager.default.fileExists(atPath: tempURL.path) {
                do {
                    try FileManager.default.removeItem(at: tempURL)
                    print("  🗑 Cleaned up temp file: \(tempURL.lastPathComponent)")
                } catch {
                    print("  ⚠️ Failed to remove temp file: \(error)")
                }
            }
        }
        
        // Build the asset
        let asset = AVAsset(url: item.url)
        guard let videoTrack = asset.tracks(withMediaType: .video).first else {
            print("  ✗ No video track found")
            cleanupTemp()
            return false
        }
        
        // Set up reader
        let reader: AVAssetReader
        do {
            reader = try AVAssetReader(asset: asset)
        } catch {
            print("  ✗ Failed to create reader: \(error)")
            cleanupTemp()
            return false
        }
        
        // Compute target dimensions
        let natural = videoTrack.naturalSize.applying(videoTrack.preferredTransform)
        let srcW = Int(abs(natural.width).rounded())
        let srcH = Int(abs(natural.height).rounded())
        
        let scaleFactor = settings.scale.factor
        let targetW = max(2, Int(Double(srcW) * scaleFactor))
        let targetH = max(2, Int(Double(srcH) * scaleFactor))
        
        // Align to even dimensions
        let alignedW = (targetW / 2) * 2
        let alignedH = (targetH / 2) * 2
        
        print("  Encoding: \(srcW)×\(srcH) → \(alignedW)×\(alignedH)")
        
        // Get duration for progress tracking
        let totalDuration = item.meta.durationSeconds > 0 ? item.meta.durationSeconds : CMTimeGetSeconds(asset.duration)
        let frameDuration = CMTime(value: 1, timescale: CMTimeScale(videoTrack.nominalFrameRate))
        
        print("  Duration: \(totalDuration)s, FPS: \(videoTrack.nominalFrameRate)")
        
        // Video composition for scaling
        let videoComposition = AVMutableVideoComposition()
        videoComposition.renderSize = CGSize(width: alignedW, height: alignedH)
        videoComposition.frameDuration = frameDuration
        
        let instruction = AVMutableVideoCompositionInstruction()
        instruction.timeRange = CMTimeRange(start: .zero, duration: asset.duration)
        
        let layerInstruction = AVMutableVideoCompositionLayerInstruction(assetTrack: videoTrack)
        let scale = min(Double(alignedW) / Double(srcW), Double(alignedH) / Double(srcH))
        let transform = CGAffineTransform(scaleX: scale, y: scale)
        layerInstruction.setTransform(transform, at: .zero)
        
        instruction.layerInstructions = [layerInstruction]
        videoComposition.instructions = [instruction]
        
        // Video output
        let videoOutput = AVAssetReaderVideoCompositionOutput(
            videoTracks: [videoTrack],
            videoSettings: [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
        )
        videoOutput.videoComposition = videoComposition
        videoOutput.alwaysCopiesSampleData = false
        reader.add(videoOutput)
        
        // Audio output (optional)
                let audioTrack = asset.tracks(withMediaType: .audio).first
                var audioOutput: AVAssetReaderOutput?
                if let at = audioTrack {
                    let ao = AVAssetReaderTrackOutput(track: at, outputSettings: [
                        AVFormatIDKey: kAudioFormatLinearPCM
                    ])
                    ao.alwaysCopiesSampleData = false
                    reader.add(ao)
                    audioOutput = ao
                }
        
        // Set up writer
        let writer: AVAssetWriter
        do {
            let fileType: AVFileType = (settings.containerFormat == .mp4) ? .mp4 : .mov
            writer = try AVAssetWriter(outputURL: tempURL, fileType: fileType)
        } catch {
            print("  ✗ Failed to create writer: \(error)")
            cleanupTemp()
            return false
        }
        
        writer.movieTimeScale = CMTimeScale(60000)
        writer.shouldOptimizeForNetworkUse = true
        
        // Video input settings
        let codecKey = (settings.codec == .hevc) ? AVVideoCodecType.hevc.rawValue : AVVideoCodecType.h264.rawValue
        
        let bitrate = estimateBitrate(width: alignedW, height: alignedH, fps: Double(videoTrack.nominalFrameRate), settings: settings)
        
        var compressionProps: [String: Any] = [
            AVVideoAverageBitRateKey: bitrate,
            AVVideoAllowFrameReorderingKey: true,
            AVVideoMaxKeyFrameIntervalKey: max(1, Int(videoTrack.nominalFrameRate * 10))
        ]
        
        let encoderSpec: [String: Any] = [
            kVTVideoEncoderSpecification_EnableHardwareAcceleratedVideoEncoder as String: true,
            kVTVideoEncoderSpecification_RequireHardwareAcceleratedVideoEncoder as String: true
        ]
        
        let videoInputSettings: [String: Any] = [
            AVVideoCodecKey: codecKey,
            AVVideoWidthKey: alignedW,
            AVVideoHeightKey: alignedH,
            AVVideoCompressionPropertiesKey: compressionProps,
            AVVideoEncoderSpecificationKey: encoderSpec
        ]
        
        let videoInput = AVAssetWriterInput(mediaType: .video, outputSettings: videoInputSettings)
        videoInput.expectsMediaDataInRealTime = false
        writer.add(videoInput)
        
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(
            assetWriterInput: videoInput,
            sourcePixelBufferAttributes: [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                kCVPixelBufferWidthKey as String: alignedW,
                kCVPixelBufferHeightKey as String: alignedH
            ]
        )
        
        // Audio input (optional)
        var audioInput: AVAssetWriterInput?
        if audioTrack != nil {
            let audioSettings: [String: Any] = [
                AVFormatIDKey: kAudioFormatMPEG4AAC,
                AVNumberOfChannelsKey: 2,
                AVSampleRateKey: 48000,
                AVEncoderBitRateKey: 192000
            ]
            let ai = AVAssetWriterInput(mediaType: .audio, outputSettings: audioSettings)
            ai.expectsMediaDataInRealTime = false
            writer.add(ai)
            audioInput = ai
        }
        
        // Start session
        guard writer.startWriting() else {
            print("  ✗ Writer failed to start: \(writer.error?.localizedDescription ?? "unknown")")
            cleanupTemp()
            return false
        }
        
        guard reader.startReading() else {
            print("  ✗ Reader failed to start: \(reader.error?.localizedDescription ?? "unknown")")
            cleanupTemp()
            return false
        }
        
        writer.startSession(atSourceTime: .zero)
        
        let group = DispatchGroup()
        let videoQueue = DispatchQueue(label: "cli.video", qos: .userInitiated)
        let audioQueue = DispatchQueue(label: "cli.audio", qos: .userInitiated)
        
        var frameIndex: Int64 = 0
        var wasCancelled = false
        var lastProgressUpdate = Date.distantPast
        let progressUpdateInterval: TimeInterval = 0.5
        
        // Video pump with progress and cancellation
        group.enter()
        videoInput.requestMediaDataWhenReady(on: videoQueue) {
            while videoInput.isReadyForMoreMediaData {
                // Check for cancellation
                if let check = cancellationCheck, check() {
                    print("  ⚠️ Cancellation detected")
                    wasCancelled = true
                    videoInput.markAsFinished()
                    group.leave()
                    return
                }
                
                guard let sb = videoOutput.copyNextSampleBuffer(),
                      let pb = CMSampleBufferGetImageBuffer(sb) else {
                    videoInput.markAsFinished()
                    group.leave()
                    return
                }
                
                let pts = CMTimeMultiply(frameDuration, multiplier: Int32(frameIndex))
                frameIndex += 1
                
                // Update progress periodically (on main thread for UI updates)
                if totalDuration > 0, Date().timeIntervalSince(lastProgressUpdate) >= progressUpdateInterval {
                    lastProgressUpdate = Date()
                    let elapsedSeconds = CMTimeGetSeconds(pts)
                    let percentComplete = min(max(elapsedSeconds / totalDuration, 0.0), 1.0)
                    
                    DispatchQueue.main.async {
                        progressCallback?(elapsedSeconds, percentComplete)
                    }
                }
                
                if !adaptor.append(pb, withPresentationTime: pts) {
                    videoInput.markAsFinished()
                    group.leave()
                    return
                }
            }
        }
        
        // Audio pump with cancellation check
        if let audioOutput = audioOutput, let audioInput = audioInput {
            group.enter()
            audioInput.requestMediaDataWhenReady(on: audioQueue) {
                while audioInput.isReadyForMoreMediaData {
                    // Check for cancellation
                    if let check = cancellationCheck, check() {
                        wasCancelled = true
                        audioInput.markAsFinished()
                        group.leave()
                        return
                    }
                    
                    guard let sb = audioOutput.copyNextSampleBuffer() else {
                        audioInput.markAsFinished()
                        group.leave()
                        return
                    }
                    
                    if !audioInput.append(sb) {
                        audioInput.markAsFinished()
                        group.leave()
                        return
                    }
                }
            }
        }
        
        // Wait for completion
        group.wait()
        
        // If cancelled, clean up and return
        if wasCancelled {
            print("  ⚠️ Encode was cancelled, cleaning up...")
            reader.cancelReading()
            writer.cancelWriting()
            cleanupTemp()
            return false
        }
        
        // Finish writing
        videoInput.markAsFinished()
        audioInput?.markAsFinished()
        
        let semaphore = DispatchSemaphore(value: 0)
        var writeSuccess = false
        
        writer.finishWriting {
            writeSuccess = (writer.status == .completed)
            semaphore.signal()
        }
        
        semaphore.wait()
        
        guard writeSuccess else {
            print("  ✗ Writer did not complete: \(writer.error?.localizedDescription ?? "unknown")")
            cleanupTemp()
            return false
        }
        
        // Move temp to final location
        do {
            try? FileManager.default.removeItem(at: output)
            try FileManager.default.moveItem(at: tempURL, to: output)
            
            let elapsed = Date().timeIntervalSince(startTime)
            let mins = Int(elapsed) / 60
            let secs = Int(elapsed) % 60
            print("  ✓ Complete in \(mins)m \(secs)s")
            
            return true
        } catch {
            print("  ✗ Failed to finalize output: \(error)")
            cleanupTemp()
            return false
        }
    }
    
    private static func estimateBitrate(width: Int, height: Int, fps: Double, settings: Settings) -> Int {
        let crfMin = 14.0
        let crfMax = 30.0
        let crf = min(max(Double(settings.qualityCRF), crfMin), crfMax)
        let t = (crf - crfMin) / (crfMax - crfMin)
        let q = 1.0 - t
        
        let bpppfRange: (low: Double, high: Double)
        switch settings.codec {
        case .hevc: bpppfRange = (0.014, 0.060)
        case .h264: bpppfRange = (0.060, 0.160)
        case .bypass: bpppfRange = (0.060, 0.160)
        }
        
        let bpppf = bpppfRange.low + (bpppfRange.high - bpppfRange.low) * q
        let pixelsPerFrame = Double(width * height)
        let bitsPerSecond = pixelsPerFrame * fps * bpppf
        
        return Int(max(100_000, bitsPerSecond))
    }
}
