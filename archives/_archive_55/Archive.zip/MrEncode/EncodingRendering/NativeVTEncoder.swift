//
//  NativeVTEncoder.swift
//  MrEncode
//
//  Created by scott ulrich on 1/30/26.
//


import Foundation
import AVFoundation
import VideoToolbox

enum NativeVTEncoder {

    // Conservative alignment. If you want “just even”, set to 2.
    private static let dimensionAlignment: Int = 2

    private final class CancelToken {
        private let lock = NSLock()
        private var _cancelled = false
        func cancel() { lock.lock(); _cancelled = true; lock.unlock() }
        var isCancelled: Bool { lock.lock(); defer { lock.unlock() }; return _cancelled }
    }

    static func encodeItem(_ item: MediaItem, settings: Settings) {
        // CHECK GLOBAL CANCEL - Don't start if queue was cancelled
        if EncodingService.shared.wasGloballyCancelled {
            print("🛑 Skipping item (global cancel) - \(item.url.lastPathComponent)")
            DispatchQueue.main.async {
                if let idx = AppCore.shared.files.firstIndex(where: { $0.id == item.id }) {
                    AppCore.shared.files[idx].status = .queued
                    AppCore.shared.files[idx].statusReason = nil
                    // Keep isChecked as-is - user can restart queue
                }
            }
            return
        }
        
        // PAUSE CHECK: Don't start if paused (wait until resumed, or stopped)
        while EncodingService.shared.isGloballyPaused {
            // Allow Stop to break out of pause
            if EncodingService.shared.wasGloballyCancelled {
                print("🛑 Stop during pause - exiting")
                return  // Exit entirely, don't start encode
            }
            Thread.sleep(forTimeInterval: 0.5)
        }
        
        let token = CancelToken()

        // Register cancel hook
        EncodingService.registerCancelHandler(for: item.id) {
            token.cancel()
        }

        defer {
            EncodingService.unregisterCancelHandler(for: item.id)
        }

        // Mark encoding on main thread (mirror EncodeLocal behavior)
        DispatchQueue.main.async {
            if let shared = AppState.shared,
               let idx = shared.files.firstIndex(where: { $0.id == item.id }) {
                AppCore.shared.files[idx].status = .encoding
                AppCore.shared.files[idx].statusReason = nil
                AppCore.shared.files[idx].actualEncodeSeconds = nil
                AppCore.shared.files[idx].progress = 0
                AppCore.shared.files[idx].etaSeconds = nil
                AppCore.shared.files[idx].progressMode = .none
            }
        }

        // Determine planned outputURL the same way EncodeLocal does
        let outputURL: URL = {
            if let planned = item.plannedOutputURL { return planned }

            var result: URL?
            let sema = DispatchSemaphore(value: 0)
            DispatchQueue.main.async {
                defer { sema.signal() }
                if let shared = AppState.shared,
                   let idx = shared.files.firstIndex(where: { $0.id == item.id }),
                   let planned = shared.files[idx].plannedOutputURL {
                    result = planned
                } else {
                    result = OutputNamer.suggestedOutputURL(for: item.url, settings: settings)
                }
            }
            sema.wait()
            return result ?? OutputNamer.suggestedOutputURL(for: item.url, settings: settings)
        }()

        let tempURL = outputURL
            .deletingLastPathComponent()
            .appendingPathComponent(".tmp-\(UUID().uuidString)-\(outputURL.lastPathComponent)")

        // Ensure output dir exists
        do {
            try FileManager.default.createDirectory(
                at: outputURL.deletingLastPathComponent(),
                withIntermediateDirectories: true,
                attributes: nil
            )
        } catch {
            DispatchQueue.main.async {
                if let shared = AppState.shared,
                   let i = shared.files.firstIndex(where: { $0.id == item.id }) {
                    AppCore.shared.files[i].status = .error
                    AppCore.shared.files[i].statusReason = "Cannot create output folder"
                }
            }
            return
        }
        
        // Determine if overlays are needed
        let needsOverlays = settings.burnInTimecode || settings.burnInFrames || settings.burnInFilename

        let startedAt = Date()

        // Build AVAsset
        let asset = AVAsset(url: item.url)

        let videoTrack = asset.tracks(withMediaType: .video).first!

        let durationSeconds = item.meta.durationSeconds
        let durationTime = asset.duration
        
        let frameDur = snappedFrameDuration(for: videoTrack)
        let nominalFPS = snappedFPS(for: videoTrack)
        var frameIndex: Int64 = 0

        // Compute target dimensions (scale/custom) then align/pad
        let target = computeTargetDimensions(videoTrack: videoTrack, settings: settings)
        let aligned = alignDimensions(target, alignment: dimensionAlignment)

        // Build reader
        let reader: AVAssetReader
        do {
            reader = try AVAssetReader(asset: asset)
        } catch {
            fail(itemID: item.id, reason: "Reader init failed: \(error.localizedDescription)")
            return
        }
        
        // Create overlay config if needed
        let overlayConfig: OverlayRenderer.Config? = {
            guard needsOverlays else { return nil }
            
            let outputSize = CGSize(width: aligned.width, height: aligned.height)
            let fps = snappedFPS(for: videoTrack)
            
            return OverlayRenderer.Config(
                outputSize: outputSize,
                fps: fps,
                startTimecode: item.meta.startTimecode,
                filename: item.url.lastPathComponent,
                settings: settings
            )
        }()

        // Video composition for scaling/padding
        let videoComposition = makeVideoComposition(
            track: videoTrack,
            contentSize: target,     // <- NEW (pre-evenize)
            renderSize: aligned,     // <- aligned/evenized
            settings: settings
        )
        
        let videoOutput = AVAssetReaderVideoCompositionOutput(
            videoTracks: [videoTrack],
            videoSettings: [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA
            ]
        )

        videoOutput.videoComposition = videoComposition
        videoOutput.alwaysCopiesSampleData = false

        if reader.canAdd(videoOutput) { reader.add(videoOutput) }
        else {
            fail(itemID: item.id, reason: "Cannot add video output to reader")
            return
        }

        // Audio track (optional)
        let audioTrack = asset.tracks(withMediaType: .audio).first
        var audioOutput: AVAssetReaderOutput? = nil
        if let at = audioTrack {
            let ao = AVAssetReaderTrackOutput(track: at, outputSettings: [
                AVFormatIDKey: kAudioFormatLinearPCM
            ])
            ao.alwaysCopiesSampleData = false
            if reader.canAdd(ao) {
                reader.add(ao)
                audioOutput = ao
            }
        }

        // Build writer
        let writer: AVAssetWriter
        do {
            // Choose fileType from containerFormat
            let fileType: AVFileType = (settings.containerFormat == .mp4) ? .mp4 : .mov
            writer = try AVAssetWriter(outputURL: tempURL, fileType: fileType)
        } catch {
            fail(itemID: item.id, reason: "Writer init failed: \(error.localizedDescription)")
            return
        }

        // Timebase with fallback for weird timebases:
        writer.movieTimeScale = (frameDur.timescale > 1000) ? frameDur.timescale : CMTimeScale(60000)
        writer.shouldOptimizeForNetworkUse = true
        
        // Apply NCLC metadata to writer if specified**
        if let triplet = nclcTripletToApply(settings: settings, meta: item.meta) {
            applyNCLCToWriter(writer, triplet: triplet)
        }

        // Video settings (VT)
        let (videoCodecKey, profileLevel) = vtCodecSettings(settings: settings)
        let fps = snappedFPS(for: videoTrack)

        let bitrate = estimateBitrate(
            settings: settings,
            width: aligned.width,
            height: aligned.height,
            nominalFPS: fps
        )
        
        var compressionProps: [String: Any] = [
            AVVideoAverageBitRateKey: bitrate,
            AVVideoAllowFrameReorderingKey: true,
            AVVideoMaxKeyFrameIntervalKey: max(1, Int(round(fps * 10.0))) // keep your chosen GOP
        ]

        // ---- VT peak / VBV-style control + Quality settings ----
        let avgBps = bitrate

        if let profileLevel = profileLevel {
            compressionProps[AVVideoProfileLevelKey] = profileLevel
        }

        // BOOST: Raise the average bitrate directly (since we have headroom)
        let boostedAvg = Int(Double(avgBps) * 1.5)  // 50% higher baseline
        compressionProps[AVVideoAverageBitRateKey] = boostedAvg

        // Peak limits based on boosted average
        let boostedPeak = Int(Double(boostedAvg) * 4.0)
        compressionProps[kVTCompressionPropertyKey_DataRateLimits as String] = [
            boostedPeak,
            1
        ] as CFArray

        // Increase quality hint - you have file size headroom
        compressionProps[kVTCompressionPropertyKey_Quality as String] = 0.92  // Was 0.85

        // Pixel transfer properties
        compressionProps[kVTCompressionPropertyKey_PixelTransferProperties as String] = [
            kVTPixelTransferPropertyKey_ScalingMode: kVTScalingMode_Letterbox,
            kVTPixelTransferPropertyKey_DownsamplingMode: kVTDownsamplingMode_Decimate,
            kVTPixelTransferPropertyKey_DestinationYCbCrMatrix: kCVImageBufferYCbCrMatrix_ITU_R_709_2,
            kVTPixelTransferPropertyKey_DestinationColorPrimaries: kCVImageBufferColorPrimaries_ITU_R_709_2,
            kVTPixelTransferPropertyKey_DestinationTransferFunction: kCVImageBufferTransferFunction_ITU_R_709_2
        ] as CFDictionary
        
        let encoderSpec: [String: Any] = [
            kVTVideoEncoderSpecification_EnableHardwareAcceleratedVideoEncoder as String: true,
            kVTVideoEncoderSpecification_RequireHardwareAcceleratedVideoEncoder as String: true
        ]

        let videoInputSettings: [String: Any] = [
            AVVideoCodecKey: videoCodecKey,
            AVVideoWidthKey: aligned.width,
            AVVideoHeightKey: aligned.height,
            AVVideoCompressionPropertiesKey: compressionProps,
            AVVideoEncoderSpecificationKey: encoderSpec
        ]

        let videoInput = AVAssetWriterInput(mediaType: .video, outputSettings: videoInputSettings)
        videoInput.expectsMediaDataInRealTime = false
        
        videoInput.mediaTimeScale = frameDur.timescale
        
        // Keep orientation consistent
        videoInput.transform = videoTrack.preferredTransform

        let adaptor = AVAssetWriterInputPixelBufferAdaptor(
            assetWriterInput: videoInput,
            sourcePixelBufferAttributes: [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                kCVPixelBufferWidthKey as String: aligned.width,
                kCVPixelBufferHeightKey as String: aligned.height
            ]
        )

        guard writer.canAdd(videoInput) else {
            fail(itemID: item.id, reason: "Cannot add video input to writer")
            return
        }
        writer.add(videoInput)

        // Audio output settings: passthrough if possible, else AAC
        var audioInput: AVAssetWriterInput? = nil
        if let _ = audioTrack {
            // If MP4, AAC is safest. For MOV, AAC is also fine.
            let audioSettings: [String: Any] = [
                AVFormatIDKey: kAudioFormatMPEG4AAC,
                AVNumberOfChannelsKey: 2,
                AVSampleRateKey: 48000,
                AVEncoderBitRateKey: 192000
            ]
            let ai = AVAssetWriterInput(mediaType: .audio, outputSettings: audioSettings)
            ai.expectsMediaDataInRealTime = false
            if writer.canAdd(ai) {
                writer.add(ai)
                audioInput = ai
            }
        }

        // Start session
        if !writer.startWriting() {
            fail(itemID: item.id, reason: "Writer start failed: \(writer.error?.localizedDescription ?? "Unknown")")
            return
        }

        if !reader.startReading() {
            fail(itemID: item.id, reason: "Reader start failed: \(reader.error?.localizedDescription ?? "Unknown")")
            return
        }

        writer.startSession(atSourceTime: .zero)
        let group = DispatchGroup()
        let videoQueue = DispatchQueue(label: "mrencode.native.video", qos: .userInitiated)
        let audioQueue = DispatchQueue(label: "mrencode.native.audio", qos: .userInitiated)

        var lastVideoPTS: CMTime = .zero
        var didFail = false

        // VIDEO pump (FORCED CFR via adaptor)
        group.enter()
        videoInput.requestMediaDataWhenReady(on: videoQueue) {
            while videoInput.isReadyForMoreMediaData {
                // ✅ CHECK 1: Before reading next sample
                if token.isCancelled {
                    videoInput.markAsFinished()
                    group.leave()
                    return
                }

                guard let sb = videoOutput.copyNextSampleBuffer() else {
                    videoInput.markAsFinished()
                    group.leave()
                    return
                }

                guard let pb = CMSampleBufferGetImageBuffer(sb) else {
                    didFail = true
                    videoInput.markAsFinished()
                    group.leave()
                    return
                }

                // ✅ CHECK 2: After sample buffer processing, before heavy operations
                if token.isCancelled {
                    videoInput.markAsFinished()
                    group.leave()
                    return
                }

                // Apply NCLC to pixel buffer if specified
                if let triplet = nclcTripletToApply(settings: settings, meta: item.meta) {
                    applyNCLCToPixelBuffer(pb, triplet: triplet)
                }
                
                // Draw overlays if enabled
                if let config = overlayConfig {
                    OverlayRenderer.drawOverlays(
                        on: pb,
                        frameNumber: frameIndex,
                        config: config
                    )
                }

                let outPTS = CMTimeMultiply(frameDur, multiplier: Int32(frameIndex))
                frameIndex += 1
                lastVideoPTS = outPTS

                // Progress update
                if durationSeconds > 0 {
                    let p = min(max(CMTimeGetSeconds(outPTS) / durationSeconds, 0.0), 1.0)
                    DispatchQueue.main.async {
                        if let idx = AppCore.shared.files.firstIndex(where: { $0.id == item.id }) {
                            AppCore.shared.files[idx].progress = p
                        }
                    }
                }

                // ✅ CHECK 3: Right before the slow disk write operation
                if token.isCancelled {
                    videoInput.markAsFinished()
                    group.leave()
                    return
                }

                // This is the potentially slow operation on network mounts
                if !adaptor.append(pb, withPresentationTime: outPTS) {
                    didFail = true
                    videoInput.markAsFinished()
                    group.leave()
                    return
                }
                
                // ✅ CHECK 4: Immediately after disk write (catches cancel during write)
                if token.isCancelled {
                    videoInput.markAsFinished()
                    group.leave()
                    return
                }
            }
        }


        // AUDIO pump (optional)
        if let audioOutput = audioOutput, let audioInput = audioInput {
            group.enter()
            audioInput.requestMediaDataWhenReady(on: audioQueue) {
                while audioInput.isReadyForMoreMediaData {
                    // ✅ CHECK 1: Before reading next sample
                    if token.isCancelled {
                        audioInput.markAsFinished()
                        group.leave()
                        return
                    }

                    guard let sb = audioOutput.copyNextSampleBuffer() else {
                        audioInput.markAsFinished()
                        group.leave()
                        return
                    }

                    // ✅ CHECK 2: Before the potentially slow write
                    if token.isCancelled {
                        audioInput.markAsFinished()
                        group.leave()
                        return
                    }

                    if !audioInput.append(sb) {
                        didFail = true
                        audioInput.markAsFinished()
                        group.leave()
                        return
                    }
                    
                    // ✅ CHECK 3: After the write operation
                    if token.isCancelled {
                        audioInput.markAsFinished()
                        group.leave()
                        return
                    }
                }
            }
        }

        // Finish
        group.wait()

        if token.isCancelled {
            reader.cancelReading()
            writer.cancelWriting()
            cleanupTemp(tempURL)

            DispatchQueue.main.async {
                // Keep the item, reset to queued state
                if let idx = AppCore.shared.files.firstIndex(where: { $0.id == item.id }) {
                    AppCore.shared.files[idx].status = .queued
                    AppCore.shared.files[idx].statusReason = "Encode cancelled"
                    AppCore.shared.files[idx].progress = nil
                    AppCore.shared.files[idx].etaSeconds = nil
                    AppCore.shared.files[idx].progressMode = .none
                    AppCore.shared.files[idx].isChecked = false  // Uncheck so it doesn't auto-restart
                    
                    AppState.shared?.pushMessage(
                        level: .info,
                        "Local encode cancelled",
                        filename: item.url.lastPathComponent
                    )
                }
            }
            return
        }

        if didFail || reader.status == .failed || writer.status == .failed {
            reader.cancelReading()
            writer.cancelWriting()
            cleanupTemp(tempURL)

            let err = writer.error?.localizedDescription ?? reader.error?.localizedDescription ?? "Unknown encode failure"
            fail(itemID: item.id, reason: err)
            return
        }

        // End writing
        videoInput.markAsFinished()
        audioInput?.markAsFinished()

        writer.finishWriting {
            let finishedAt = Date()

            if writer.status != .completed {
                cleanupTemp(tempURL)
                fail(itemID: item.id, reason: writer.error?.localizedDescription ?? "Writer did not complete")
                return
            }

            // Finalize move temp -> final
            do {
                if FileManager.default.fileExists(atPath: outputURL.path) {
                    if item.allowOverwrite {
                        try? FileManager.default.removeItem(at: outputURL)
                    } else {
                        throw NSError(domain: "MrEncode", code: 1,
                                      userInfo: [NSLocalizedDescriptionKey: "Destination exists and overwrite is not allowed."])
                    }
                }

                try FileManager.default.moveItem(at: tempURL, to: outputURL)

                DispatchQueue.main.async {
                    AppCore.shared.localEncodeDidComplete(
                        itemID: item.id,
                        outputURL: outputURL,
                        errorText: nil,
                        encodeSeconds: finishedAt.timeIntervalSince(startedAt)
                    )

                    let secs = Int(round(finishedAt.timeIntervalSince(startedAt)))
                    let mins = secs / 60
                    let rem  = secs % 60
                    AppState.shared?.pushMessage(
                        level: .info,
                        "Local encode complete (\(mins)m \(String(format: "%02d", rem))s)",
                        filename: item.url.lastPathComponent
                    )
                }
            } catch {
                cleanupTemp(tempURL)
                fail(itemID: item.id, reason: "Failed to finalize output: \(error.localizedDescription)")
            }
        }
    }

    // MARK: Helpers, Compression

    private static func fail(itemID: UUID, reason: String) {
        DispatchQueue.main.async {
            if let idx = AppCore.shared.files.firstIndex(where: { $0.id == itemID }) {
                AppCore.shared.files[idx].status = .error
                AppCore.shared.files[idx].statusReason = reason
            }
        }
    }

    private static func cleanupTemp(_ url: URL) {
        try? FileManager.default.removeItem(at: url)
    }

    private static func alignDimensions(_ size: (width: Int, height: Int), alignment: Int) -> (width: Int, height: Int) {
        func up(_ v: Int) -> Int {
            let a = max(2, alignment)
            return ((v + a - 1) / a) * a
        }
        return (up(size.width), up(size.height))
    }

    private static func nominalFrameRate(_ track: AVAssetTrack) -> Double {
        let fps = Double(track.nominalFrameRate)
        return (fps > 1.0) ? fps : 30.0
    }

    private static func computeTargetDimensions(videoTrack: AVAssetTrack, settings: Settings) -> (width: Int, height: Int) {
        let natural = videoTrack.naturalSize.applying(videoTrack.preferredTransform)
        let srcW = Int(abs(natural.width))
        let srcH = Int(abs(natural.height))

        switch settings.scale {
        case .oneToOne:
            return (srcW, srcH)

        case .half, .quarter:
            let f = settings.scale.factor
            return (max(2, Int(Double(srcW) * f)), max(2, Int(Double(srcH) * f)))

        case .custom:
            return (max(2, settings.customScaleWidth), max(2, settings.customScaleHeight))
        }
    }

    private static func makeVideoComposition(
        track: AVAssetTrack,
        contentSize: (width: Int, height: Int),   // the intended scaled size (pre-evenize)
        renderSize: (width: Int, height: Int),    // the final evenized buffer
        settings: Settings
    ) -> AVMutableVideoComposition {

        let comp = AVMutableVideoComposition()
        comp.renderSize = CGSize(width: renderSize.width, height: renderSize.height)
        comp.frameDuration = snappedFrameDuration(for: track)

        let instruction = AVMutableVideoCompositionInstruction()
        instruction.timeRange = CMTimeRange(start: .zero, duration: track.asset?.duration ?? .zero)

        let layer = AVMutableVideoCompositionLayerInstruction(assetTrack: track)

        // IMPORTANT:
        // Use the same oriented size basis as computeTargetDimensions so our math matches.
        let naturalOriented = track.naturalSize.applying(track.preferredTransform)
        let srcW = CGFloat(abs(naturalOriented.width))
        let srcH = CGFloat(abs(naturalOriented.height))

        let dstW = CGFloat(renderSize.width)
        let dstH = CGFloat(renderSize.height)

        // Default anchor: center (unless custom uses its own)
        let anchor: BurnInPosition = (settings.scale == .custom) ? settings.customScaleAnchor : .center

        // CUSTOM mode: preserve your existing semantics
        if settings.scale == .custom {
            let mode: CustomScaleMode = settings.customScaleMode

            let sx = dstW / srcW
            let sy = dstH / srcH

            let scale: CGFloat
            switch mode {
            case .stretch:
                scale = 1.0 // handled as sx/sy below
            case .fit:
                scale = min(sx, sy)
            case .fill:
                scale = max(sx, sy)
            }

            let scaledW: CGFloat
            let scaledH: CGFloat
            if mode == .stretch {
                scaledW = dstW
                scaledH = dstH
            } else {
                scaledW = srcW * scale
                scaledH = srcH * scale
            }

            let (tx, ty) = anchorTranslation(
                dstW: dstW,
                dstH: dstH,
                scaledW: scaledW,
                scaledH: scaledH,
                anchor: anchor
            )

            var t = CGAffineTransform.identity
            if mode == .stretch {
                t = t.scaledBy(x: sx, y: sy)
            } else {
                t = t.scaledBy(x: scale, y: scale)
                t = t.translatedBy(x: tx / scale, y: ty / scale)
            }

            layer.setTransform(t, at: .zero)
            instruction.layerInstructions = [layer]
            comp.instructions = [instruction]
            return comp
        }

        // NON-CUSTOM (1:1, half, quarter):
        // Scale to contentSize, then pad into renderSize. This prevents "evenize stretch".
        let contentW = CGFloat(contentSize.width)
        let contentH = CGFloat(contentSize.height)

        // If content is larger than render (shouldn't happen with your align-up),
        // clamp to render to avoid negative padding math.
        let clampedContentW = min(contentW, dstW)
        let clampedContentH = min(contentH, dstH)

        // Uniform scale to preserve aspect. For your non-custom cases this should
        // effectively be exactly the factor (1.0, 0.5, 0.25), but remains robust.
        let scale = min(clampedContentW / srcW, clampedContentH / srcH)

        let scaledW = srcW * scale
        let scaledH = srcH * scale

        let (tx, ty) = anchorTranslation(
            dstW: dstW,
            dstH: dstH,
            scaledW: scaledW,
            scaledH: scaledH,
            anchor: anchor
        )

        var t = CGAffineTransform.identity
        t = t.scaledBy(x: scale, y: scale)
        t = t.translatedBy(x: tx / scale, y: ty / scale)

        layer.setTransform(t, at: .zero)

        instruction.layerInstructions = [layer]
        comp.instructions = [instruction]
        return comp
    }


    /// Calculate translation offset based on anchor position
    private static func anchorTranslation(
        dstW: CGFloat,
        dstH: CGFloat,
        scaledW: CGFloat,
        scaledH: CGFloat,
        anchor: BurnInPosition
    ) -> (tx: CGFloat, ty: CGFloat) {
        
        let remainingW = dstW - scaledW
        let remainingH = dstH - scaledH
        
        let tx: CGFloat
        let ty: CGFloat
        
        switch anchor {
        case .upperLeft:
            tx = 0
            ty = 0
        case .upperCenter:
            tx = remainingW * 0.5
            ty = 0
        case .upperRight:
            tx = remainingW
            ty = 0
        case .middleLeft:
            tx = 0
            ty = remainingH * 0.5
        case .center:
            tx = remainingW * 0.5
            ty = remainingH * 0.5
        case .middleRight:
            tx = remainingW
            ty = remainingH * 0.5
        case .lowerLeft:
            tx = 0
            ty = remainingH
        case .lowerCenter:
            tx = remainingW * 0.5
            ty = remainingH
        case .lowerRight:
            tx = remainingW
            ty = remainingH
        }
        
        return (tx, ty)
    }

    private static func vtCodecSettings(settings: Settings) -> (codecKey: String, profileLevel: String?) {
        switch settings.codec {
        case .h264:
            return (AVVideoCodecType.h264.rawValue, AVVideoProfileLevelH264HighAutoLevel)

        case .hevc:
            return (AVVideoCodecType.hevc.rawValue, nil)

        case .bypass:
            // Should not reach native encoder in bypass mode; treat as h264 fallback
            return (AVVideoCodecType.h264.rawValue, AVVideoProfileLevelH264HighAutoLevel)
        }
    }
    
    private static func estimateBitrate(
        settings: Settings,
        width: Int,
        height: Int,
        nominalFPS: Double
    ) -> Int {

        // 1) Map stored CRF (14..30) to q in 0..1 (higher = better)
        let crfMin = 14.0
        let crfMax = 30.0
        let crf = min(max(Double(settings.qualityCRF), crfMin), crfMax)
        let t = (crf - crfMin) / (crfMax - crfMin) // 0(best)..1(worst)
        let q = 1.0 - t                             // 1(best)..0(worst)

        // 2) Baseline bpppf envelope per codec
        // These set the overall "size behavior" of the slider.
        let bpppfRange: (low: Double, high: Double)
        switch settings.codec {
        case .hevc:
            // Tuned baseline that matched your ffmpeg baseline around 75%
            bpppfRange = (0.014, 0.060)
        case .h264:
            bpppfRange = (0.060, 0.160)
        case .bypass:
            // Not used for VT encode, but keep sane
            bpppfRange = (0.060, 0.160)
        }

        // 3) Midrange shaping (helps 75% without inflating endpoints)
        let gammaMid = 0.70
        let shapedQ = pow(q, gammaMid)

        var bpppf = bpppfRange.low + (bpppfRange.high - bpppfRange.low) * shapedQ

        // 4) Floor protection so 0% is still usable (you said you have headroom to go smaller)
        // This is independent of minBps and behaves consistently across res/fps.
        let bpppfFloor: Double
        switch settings.codec {
        case .hevc: bpppfFloor = 0.005
        case .h264: bpppfFloor = 0.025
        case .bypass: bpppfFloor = 0.025
        }
        bpppf = max(bpppf, bpppfFloor)

        // 5) Top-end headroom: aggressive ramp above a knee so 100% can be "maxed out"
        let knee = 0.85
        let topBoostMax = 9.0   // 100% multiplier becomes (1 + 9) = 10×

        if q > knee {
            let x = (q - knee) / (1.0 - knee) // 0..1 above knee
            let topCurve = x * x              // quadratic ramp
            let boost = 1.0 + topBoostMax * topCurve
            bpppf *= boost
        }

        // 6) Convert bpppf to bitrate
        let pixelsPerFrame = Double(width * height)
        let bitsPerSecond = pixelsPerFrame * nominalFPS * bpppf

        // 7) Clamp using a bpppf-derived max, not a fixed maxBps (resolution/fps aware)
        let minBps = 100_000.0

        let maxBpppf: Double
        switch settings.codec {
        case .hevc:
            // "Near-lossless ceiling" for HEVC; adjust to taste
            maxBpppf = 1.0
        case .h264:
            maxBpppf = 1.5
        case .bypass:
            maxBpppf = 1.5
        }

        let maxBps = pixelsPerFrame * nominalFPS * maxBpppf

        return Int(min(max(bitsPerSecond, minBps), maxBps))
    }

    /// Debug helper: what does a maxBpppf ceiling imply as Mbps for this clip?
    private static func maxMbpsForCeiling(width: Int, height: Int, fps: Double, maxBpppf: Double) -> Double {
        let maxBps = Double(width * height) * fps * maxBpppf
        return maxBps / 1_000_000.0
    }
    
    
    private static func snappedFrameDuration(for track: AVAssetTrack) -> CMTime {
        // Use nominalFrameRate as the primary classification signal, but snap to canonical timebases.
        // (minFrameDuration can be "almost" NTSC which leads to AE showing 29.969 etc.)
        let fpsNom = Double(track.nominalFrameRate)

        // Snap common NTSC rates
        if abs(fpsNom - 23.976) < 0.02 || abs(fpsNom - 23.98) < 0.02 {
            return CMTime(value: 1001, timescale: 24000) // 24000/1001
        }
        if abs(fpsNom - 29.97) < 0.02 {
            return CMTime(value: 1001, timescale: 30000) // 30000/1001
        }
        if abs(fpsNom - 59.94) < 0.02 {
            return CMTime(value: 1001, timescale: 60000) // 60000/1001
        }

        // Snap common integer-ish rates
        let commonInts: [Int32] = [24, 25, 30, 48, 50, 60]
        for r in commonInts {
            if abs(fpsNom - Double(r)) < 0.01 {
                return CMTime(value: 1, timescale: r)
            }
        }

        // If minFrameDuration is valid, use it (but normalize to a stable timescale to avoid weird decimals).
        let mfd = track.minFrameDuration
        if mfd.isValid, mfd.value > 0, mfd.timescale > 0 {
            // Normalize to a sane timescale without changing the actual duration.
            // 600 is common for media timebases.
            return CMTimeConvertScale(mfd, timescale: 600, method: .roundHalfAwayFromZero)
        }

        // Last resort: default to 30 exact
        return CMTime(value: 1, timescale: 30)
    }

    private static func snappedFPS(for track: AVAssetTrack) -> Double {
        let fd = snappedFrameDuration(for: track)
        let s = CMTimeGetSeconds(fd)
        return (s > 0) ? (1.0 / s) : 30.0
    }
    
    /// Returns an exact per-frame duration for common fractional rates,
    /// otherwise a stable duration using a high timescale to minimize rounding.
    static func exactFrameDuration(for nominalFPS: Double) -> CMTime {
        let table: [(fps: Double, dur: CMTime)] = [
            (24000.0/1001.0, CMTime(value: 1001, timescale: 24000)), // 23.976
            (30000.0/1001.0, CMTime(value: 1001, timescale: 30000)), // 29.97
            (60000.0/1001.0, CMTime(value: 1001, timescale: 60000)), // 59.94

            (24.0, CMTime(value: 1, timescale: 24)),
            (25.0, CMTime(value: 1, timescale: 25)),
            (30.0, CMTime(value: 1, timescale: 30)),
            (50.0, CMTime(value: 1, timescale: 50)),
            (60.0, CMTime(value: 1, timescale: 60))
        ]

        for (fps, dur) in table {
            if abs(nominalFPS - fps) < 0.02 {
                return dur
            }
        }

        let fps = max(1.0, nominalFPS)
        return CMTime(seconds: 1.0 / fps, preferredTimescale: 60000)
    }
    
    
    // MARK: Helpers, NCLC
    
    /// Determine the NCLC triplet to apply based on settings and metadata
    private static func nclcTripletToApply(settings: Settings, meta: MediaMetadata) -> NCLCMap.Triplet? {
        let tag = settings.nclcTag.trimmingCharacters(in: .whitespacesAndNewlines)
        
        // "No Change" means passthrough existing metadata
        if tag.lowercased() == "no change" {
            // Try to build from existing metadata
            guard let p = meta.colorPrimaries,
                  let t = meta.transferFunction,
                  let m = meta.ycbcrMatrix,
                  !p.isEmpty, !t.isEmpty, !m.isEmpty else {
                return nil
            }
            return NCLCMap.Triplet(primaries: p, trc: t, matrix: m)
        }
        
        // Look up the triplet from the tag selection
        return NCLCMap.lookup(labelOrCode: tag)
    }

    /// Map NCLC string codes to CoreVideo constants
    private static func nclcToColorAttachments(triplet: NCLCMap.Triplet) -> [String: Any] {
        var attachments: [String: Any] = [:]
        
        // Color Primaries
        let primaries: CFString = {
            switch triplet.primaries {
            case "1":  return kCVImageBufferColorPrimaries_ITU_R_709_2
            case "5":  return kCVImageBufferColorPrimaries_EBU_3213
            case "6":  return kCVImageBufferColorPrimaries_SMPTE_C
            case "9":  return kCVImageBufferColorPrimaries_ITU_R_2020
            case "12": return kCVImageBufferColorPrimaries_P3_D65
            default:   return kCVImageBufferColorPrimaries_ITU_R_709_2
            }
        }()
        attachments[kCVImageBufferColorPrimariesKey as String] = primaries
        
        // Transfer Function
        let transferFunction: CFString = {
            switch triplet.trc {
            case "1":  return kCVImageBufferTransferFunction_ITU_R_709_2
            case "4":  return kCVImageBufferTransferFunction_UseGamma
            case "5":  return kCVImageBufferTransferFunction_UseGamma
            case "13": return kCVImageBufferTransferFunction_sRGB
            case "16": return kCVImageBufferTransferFunction_SMPTE_ST_2084_PQ
            case "18": return kCVImageBufferTransferFunction_ITU_R_2100_HLG
            default:   return kCVImageBufferTransferFunction_ITU_R_709_2
            }
        }()
        attachments[kCVImageBufferTransferFunctionKey as String] = transferFunction
        
        // Gamma override for codes 4 and 5
        if triplet.trc == "4" {
            attachments[kCVImageBufferGammaLevelKey as String] = 2.2
        } else if triplet.trc == "5" {
            attachments[kCVImageBufferGammaLevelKey as String] = 2.8
        }
        
        // YCbCr Matrix
        let matrix: CFString = {
            switch triplet.matrix {
            case "1":  return kCVImageBufferYCbCrMatrix_ITU_R_709_2
            case "5":  return kCVImageBufferYCbCrMatrix_ITU_R_601_4
            case "6":  return kCVImageBufferYCbCrMatrix_ITU_R_601_4
            case "9":  return kCVImageBufferYCbCrMatrix_ITU_R_2020
            case "10": return kCVImageBufferYCbCrMatrix_ITU_R_2020 // PQ constant luma variant
            default:   return kCVImageBufferYCbCrMatrix_ITU_R_709_2
            }
        }()
        attachments[kCVImageBufferYCbCrMatrixKey as String] = matrix
        
        return attachments
    }

    /// Apply NCLC metadata to the AVAssetWriter (for file-level metadata)
    private static func applyNCLCToWriter(_ writer: AVAssetWriter, triplet: NCLCMap.Triplet) {
        let attachments = nclcToColorAttachments(triplet: triplet)
        
        // Store as metadata on the writer
        var metadataItems: [AVMetadataItem] = []
        
        // Create metadata items for color space
        for (key, value) in attachments {
            let item = AVMutableMetadataItem()
            item.keySpace = .quickTimeMetadata
            item.key = key as NSString
            
            // Handle both CFString and NSNumber types
            if let cfString = value as? String {
                item.value = cfString as NSString
            } else if let number = value as? NSNumber {
                item.value = number
            }
            
            metadataItems.append(item)
        }
        
        writer.metadata = metadataItems
    }

    /// Apply NCLC metadata directly to pixel buffers during encoding
    private static func applyNCLCToPixelBuffer(_ pixelBuffer: CVPixelBuffer, triplet: NCLCMap.Triplet) {
        let attachments = nclcToColorAttachments(triplet: triplet)
        
        // Apply as CVPixelBuffer attachments
        for (key, value) in attachments {
            CVBufferSetAttachment(
                pixelBuffer,
                key as CFString,
                value as CFTypeRef,
                .shouldPropagate
            )
        }
    }


}
