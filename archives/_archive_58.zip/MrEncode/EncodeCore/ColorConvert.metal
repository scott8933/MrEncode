//
//  ColorConverts.metal
//  MrEncode
//
//  Created by scott ulrich on 2/11/26.
//


#include <metal_stdlib>
using namespace metal;

inline float3 RGB_FROM_BGRA(float4 bgra) {
    // IMPORTANT:
    // For MTLPixelFormat.bgra8Unorm, Metal already swizzles to RGBA on read().
    // So bgra.x/y/z are actually R/G/B in shader space.
    return float3(bgra.x, bgra.y, bgra.z);
}

inline void rgb_to_ycbcr_709_full(float3 rgb, thread float &y, thread float &cb, thread float &cr) {
    y  = dot(rgb, float3(0.2126, 0.7152, 0.0722));
    cb = (rgb.b - y) / (2.0 * (1.0 - 0.0722)) + 0.5;
    cr = (rgb.r - y) / (2.0 * (1.0 - 0.2126)) + 0.5;
}

kernel void bgra_to_p010_709_videorange(
    texture2d<float, access::sample>  src      [[texture(0)]],
    texture2d<float, access::write>   dstY     [[texture(1)]],
    texture2d<float, access::write>   dstUV    [[texture(2)]],
    uint2 gid [[thread_position_in_grid]]
) {
    uint w = src.get_width();
    uint h = src.get_height();
    if (gid.x >= w || gid.y >= h) return;

    // Avoid sampling coords; read exact pixel.
    // src is bgra8Unorm, so read() returns normalized floats in BGRA order.
    float4 bgra = src.read(gid);
    float3 rgb  = RGB_FROM_BGRA(bgra);

    float y, cb, cr;
    rgb_to_ycbcr_709_full(rgb, y, cb, cr);

    // map once to video-range (still normalized float)
    float yV = clamp(y, 0.0, 1.0);
    dstY.write(float4(yV, 0, 0, 1), gid);

    // UV: 2x2 average, written at even-even threads (half-res plane)
    if (((gid.x | gid.y) & 1u) == 0u) {
        float cbAcc = 0.0;
        float crAcc = 0.0;

        for (uint dy = 0; dy < 2; ++dy) {
            for (uint dx = 0; dx < 2; ++dx) {
                uint2 p = uint2(min(gid.x + dx, w - 1), min(gid.y + dy, h - 1));
                float4 b = src.read(p);
                float3 r = RGB_FROM_BGRA(b);

                float yy, cbb, crr;
                rgb_to_ycbcr_709_full(r, yy, cbb, crr);
                cbAcc += cbb;
                crAcc += crr;
            }
        }

        float cbAvg = cbAcc * 0.25;
        float crAvg = crAcc * 0.25;

        float cbV = clamp(cbAvg, 0.0, 1.0);
        float crV = clamp(crAvg, 0.0, 1.0);

        uint2 uvCoord = uint2(gid.x >> 1, gid.y >> 1);
        dstUV.write(float4(cbV, crV, 0, 1), uvCoord);
    }
}
