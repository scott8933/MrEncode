//
//  EncodingService.swift
//  MrEncode
//
//  Created by Scott Ulrich on 9/23/25.
//


//
// MARK: - EncodingService.swift
//

import Foundation
import SwiftUI
import Combine

/// Coordinates encoding operations between local and remote modes
class EncodingService: ObservableObject {
    static let shared = EncodingService()
    
    private init() {}
    
    // MARK: - Process Management for Cancellation
    private static var activeProcesses: [UUID: Process] = [:]
    private static var processQueue = DispatchQueue(label: "mrencode.processes", attributes: .concurrent)
    
    // MARK: - Cancellation handlers for non-Process backends (Native VT)
    private static var activeCancelHandlers: [UUID: () -> Void] = [:]
    
    static func registerCancelHandler(for itemID: UUID, _ handler: @escaping () -> Void) {
        processQueue.async(flags: .barrier) {
            activeCancelHandlers[itemID] = handler
        }
    }
    
    static func unregisterCancelHandler(for itemID: UUID) {
        processQueue.async(flags: .barrier) {
            activeCancelHandlers.removeValue(forKey: itemID)
        }
    }
    
    
    /// Global pause (UI + scheduler gate); not persisted
    @Published var isGloballyPaused: Bool = false
    
    // ✅ PATCH: Add global cancel flag
    /// Global cancel flag - set when user clicks Stop
    private var _wasGloballyCancelled: Bool = false
    private let cancelLock = NSLock()
    
    var wasGloballyCancelled: Bool {
        cancelLock.lock()
        defer { cancelLock.unlock() }
        return _wasGloballyCancelled
    }
    
    private func setGloballyCancelled(_ value: Bool) {
        cancelLock.lock()
        _wasGloballyCancelled = value
        cancelLock.unlock()
    }
    
    /// Submit items for encoding
    func submitItems(_ items: [MediaItem], settings: Settings, onStatusUpdate: @escaping (UUID, EncodeStatus, String?) -> Void) {
        guard !items.isEmpty else { return }
        
        // ✅ PATCH: Clear cancel flag when starting fresh batch
        setGloballyCancelled(false)
        
        // Dispatch to the selected run mode
        switch settings.runMode {
        case .localFFmpeg:
            EncodeLocal.run(items: items, settings: settings)
        case .remoteDeadline:
            EncodeRemote.run(items: items, settings: settings)
        }
    }
    
    /// Cancel all active encoding processes
    func cancelAllEncoding() {
        // ✅ PATCH: Set global cancel flag first
        setGloballyCancelled(true)
        
        Self.processQueue.async(flags: .barrier) {
            // Cancel Process-based encodes (ffmpeg)
            for (id, process) in Self.activeProcesses {
                if process.isRunning {
                    print("🛑 Terminating process for item \(id)")
                    process.terminate()
                    
                    DispatchQueue.global().asyncAfter(deadline: .now() + 2.0) {
                        if process.isRunning {
                            print("🔥 Force-killing process for item \(id)")
                            kill(process.processIdentifier, SIGKILL)
                        }
                    }
                }
            }
            Self.activeProcesses.removeAll()
            
            // Cancel Native VT encodes
            for (id, handler) in Self.activeCancelHandlers {
                print("🛑 Cancelling native encode for item \(id)")
                handler()
            }
            Self.activeCancelHandlers.removeAll()
        }
    }
    
    /// Register a process for cancellation tracking
    static func registerProcess(_ process: Process, for itemID: UUID) {
        processQueue.async(flags: .barrier) {
            activeProcesses[itemID] = process
        }
    }
    
    /// Unregister a process (typically when encoding completes)
    static func unregisterProcess(for itemID: UUID) {
        processQueue.async(flags: .barrier) {
            activeProcesses.removeValue(forKey: itemID)
        }
    }
}
