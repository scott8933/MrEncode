// =============================
// File: EncodeLocal.swift - Native-Only Version
// =============================

import Foundation
import AVFoundation

enum EncodeLocal {
    
    private static let encodeQueue = DispatchQueue(label: "mrencode.local.encode.serial")

    /// Run local encodes using native VideoToolbox
    static func run(items: [MediaItem], settings: Settings, ffmpegPath: String? = nil) {
        
        // Check if overlays are active (requires encoding even in bypass mode)
        let needsOverlays = settings.burnInTimecode || settings.burnInFrames || settings.burnInFilename
        
        print("MODE: Local (native AVFoundation/VideoToolbox)")
        print("Quality: \(settings.qualityCRF)  Scale: \(settings.scale.rawValue)  NCLC: \(settings.nclcTag)")
        
        if needsOverlays && settings.codec == .bypass {
            print("  → Overlays active with bypass codec: encoding required")
        }

        for item in items {
            // CHECK CANCEL - Stop the entire queue if cancelled
            if EncodingService.shared.wasGloballyCancelled {
                print("🛑 Global cancel detected - stopping queue")
                break
            }
            
            // PAUSE CHECK: Wait here if paused (check every 500ms, exit if cancelled)
            while EncodingService.shared.isGloballyPaused {
                // Allow Stop to break out of pause
                if EncodingService.shared.wasGloballyCancelled {
                    print("🛑 Stop during pause - exiting")
                    break
                }
                Thread.sleep(forTimeInterval: 0.5)
            }
            
            if item.status == .blocked { continue }
            if item.status == .encoding { continue }

            encodeQueue.async {
                NativeVTEncoder.encodeItem(item, settings: settings)
            }
        }
    }
}
