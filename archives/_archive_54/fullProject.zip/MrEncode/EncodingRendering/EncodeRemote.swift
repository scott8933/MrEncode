// =============================
// File: EncodeRemote.swift
// =============================


import Foundation

/// Remote encoding via Thinkbox Deadline.
/// - Builds ffmpeg args with `FFmpegCommandBuilder`
/// - Can export **FFmpeg plugin** job bundles to Desktop (no submission)
/// - Can fetch Pools/Groups and detect `deadlinecommand`
enum EncodeRemote {
    
    // MARK: - Public entry point
    
    /// Submit a batch of items to Deadline (FFmpeg plugin jobs, one per item).
    static func run(items: [MediaItem], settings: Settings) {
        let deadlineCmd = settings.deadlineCommandPath.isEmpty
            ? (detectDeadlineCommand()
               ?? "/Applications/Thinkbox/Deadline10/Resources/deadlinecommand")
            : settings.deadlineCommandPath
        
        let ffmpegOnFarm = "/usr/local/bin/ffmpeg"

        // 1) IMMEDIATE UI FEEDBACK: Mark all items as submitting (keep them checked)
        DispatchQueue.main.async {
            for item in items {
                AppCore.shared.updateFile(id: item.id) { file in
                    guard file.status != .blocked else { return }
                    file.status = .encoding
                    file.statusReason = "Submitting to Deadline…"
                    file.progressMode = .fake
                    file.progress = nil
                    file.etaSeconds = nil
                    // ✅ Keep isChecked as-is - don't modify it here
                }
            }
        }

        DispatchQueue.global(qos: .userInitiated).async {
            // Process items sequentially to avoid overwhelming the main thread
            for item in items where item.status != .encoding && item.status != .blocked {

                // CHECK CANCEL - Stop the entire queue if cancelled
                if EncodingService.shared.wasGloballyCancelled {
                    print("🛑 Global cancel detected - stopping Deadline submissions")
                    break  // Exit loop, don't submit more jobs
                }

                // PAUSE CHECK: Wait here if paused (check every 500ms, exit if cancelled)
                while EncodingService.shared.isGloballyPaused {
                    // Allow Stop to break out of pause
                    if EncodingService.shared.wasGloballyCancelled {
                        print("🛑 Stop during pause - stopping Deadline submissions")
                        break
                    }
                    Thread.sleep(forTimeInterval: 0.5)
                }

                // Path suitability check
                if case .failure(let error) = isInputPathAcceptableForFarm(item.url) {
                    DispatchQueue.main.async {
                        AppCore.shared.updateFile(id: item.id) { file in
                            file.status = .blocked
                            file.statusReason = error.message
                            file.progressMode = .none
                            file.progress = nil
                            file.etaSeconds = nil
                        }
                        AppState.shared?.pushMessage(
                            level: .warning,
                            error.message,
                            filename: item.url.lastPathComponent,
                            code: .farmPath,
                            originKey: "farm-path"
                        )
                    }
                    continue
                }

                // Check if item is still valid for processing (ASYNC version)
                var shouldContinue = true
                let semaphore = DispatchSemaphore(value: 0)
                
                DispatchQueue.main.async {
                    defer { semaphore.signal() }
                    guard let index = AppCore.shared.index(of: item.id) else { return }

                    if AppCore.shared.file(at: index)?.status == .blocked {
                        shouldContinue = false
                    } else {
                        AppCore.shared.updateFile(at: index) { file in
                            file.status = .encoding
                            file.statusReason = "Submitting to Deadline…"
                        }
                    }
                }
                
                // Wait for main thread update but with timeout to prevent hanging
                let timeoutResult = semaphore.wait(timeout: .now() + 2.0)
                if timeoutResult == .timedOut {
                    print("Warning: Timeout waiting for main thread update")
                    continue
                }
                
                if !shouldContinue { continue }

                // Submit to Deadline
                let result = submitFFmpegJob(deadlineCmd: deadlineCmd,
                                             item: item,
                                             settings: settings,
                                             ffmpegPath: ffmpegOnFarm)

                // Update UI with result
                DispatchQueue.main.async {
                    guard let idx = AppCore.shared.index(of: item.id) else { return }

                    AppCore.shared.updateFile(at: idx) { file in
                        file.progressMode = .none
                        file.progress = nil
                        file.etaSeconds = nil

                        if result.exitCode == 0 {
                            file.finalOutputURL = result.output
                            file.status = .queued
                            file.statusReason = "Submitted to Deadline."
                            file.isChecked = false
                        } else {
                            let msg = result.rawOutput.trimmingCharacters(in: .whitespacesAndNewlines)
                            file.status = .error
                            file.statusReason = msg.isEmpty
                                ? "Deadline submit failed (code \(result.exitCode))."
                                : msg
                        }
                    }

                    if result.exitCode == 0 {
                        let jobID = extractDeadlineJobID(from: result.rawOutput)
                        let detail = buildSuccessDetail(jobID: jobID, output: result.rawOutput)

                        if let jid = jobID, !jid.isEmpty {
                            AppState.shared?.pushMessage(
                                level: .info,
                                "Remote submit successful — Job \(jid)",
                                filename: item.url.lastPathComponent,
                                code: .other,
                                originKey: "deadline-submit",
                                detail: detail,
                                jobID: jid
                            )
                        } else {
                            AppState.shared?.pushMessage(
                                level: .info,
                                "Remote submit successful",
                                filename: item.url.lastPathComponent,
                                code: .other,
                                originKey: "deadline-submit",
                                detail: detail
                            )
                        }
                    } else {
                        let detail = buildErrorDetail(exitCode: result.exitCode, output: result.rawOutput)

                        AppState.shared?.pushMessage(
                            level: .error,
                            "Remote submit failed — check status",
                            filename: item.url.lastPathComponent,
                            code: .other,
                            originKey: "deadline-submit",
                            detail: detail
                        )
                    }
                }
                
                // Small delay between submissions to prevent overwhelming the system
                Thread.sleep(forTimeInterval: 0.1)
            }
        }
    }

    // MARK: - Types
    
    struct Lists {
        var pools: [String]
        var groups: [String]
    }

    struct SubmissionResult {
        let input: URL
        let output: URL
        let exitCode: Int32
        let rawOutput: String
        let jobID: String?
    }

    // MARK: - Detect deadlinecommand

    static func detectDeadlineCommand() -> String? {
        let marker = "/Users/Shared/Thinkbox/DEADLINE_PATH"
        guard let s = try? String(contentsOfFile: marker, encoding: .utf8) else { return nil }
        let dir = s.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !dir.isEmpty else { return nil }

        let res = (dir as NSString).appendingPathComponent("deadlinecommand")
        if FileManager.default.isExecutableFile(atPath: res) { return res }

        let bin = (dir as NSString).appendingPathComponent("bin/deadlinecommand")
        if FileManager.default.isExecutableFile(atPath: bin) { return bin }

        return nil
    }

    // MARK: - Pools / Groups
    
    static func fetchLists(deadlineCmd: String) throws -> Lists {
        let pools  = try runAndCollect(deadlineCmd, ["-GetPoolNames"])
        let groups = try runAndCollect(deadlineCmd, ["-GetGroupNames"])
        return Lists(pools: pools, groups: groups)
    }

    // MARK: - Submit FFmpeg job
    
    @discardableResult
    static func submitFFmpegJob(deadlineCmd: String,
                                item: MediaItem,
                                settings: Settings,
                                ffmpegPath: String) -> SubmissionResult {
        let fm = FileManager.default
        let input  = item.url
        let output = item.plannedOutputURL ?? OutputNamer.suggestedOutputURL(for: input, settings: settings)

        // Sync metadata (ensure TC/FPS are there)
        var liveItem = item

        // Snapshot AppState.shared.files on the main actor to avoid cross-actor violations
        let currentFiles: [MediaItem] = {
            var files: [MediaItem] = []
            let semaphore = DispatchSemaphore(value: 0)
            DispatchQueue.main.async {
                if let shared = AppState.shared {
                    files = shared.files
                }
                semaphore.signal()
            }
            // Wait briefly for the snapshot to avoid racing; fall back to empty on timeout
            _ = semaphore.wait(timeout: .now() + 0.5)
            return files
        }()

        if let cur = currentFiles.first(where: { $0.url == item.url }) {
            liveItem.meta.coalesce(with: cur.meta)
        }

        if liveItem.meta.startTimecode == nil || liveItem.meta.nominalFPS == nil {
            let fresh = MetadataExtractor.extract(for: liveItem.url)
            liveItem.meta.coalesce(with: fresh)
            DispatchQueue.main.async {
                AppCore.shared.updateFile(id: liveItem.id) { file in
                    file.meta = liveItem.meta
                }
            }
        }

        let args = FFmpegCommandBuilder.buildArgs(item: liveItem, output: output, settings: settings)
        let outputArgs = ffmpegOutputArgs(fromFullArgs: args, input: input, output: output)

        let tmpDir = URL(fileURLWithPath: NSTemporaryDirectory(), isDirectory: true)
            .appendingPathComponent("MrEncode_\(UUID().uuidString)", isDirectory: true)

        do {
            try fm.createDirectory(at: tmpDir, withIntermediateDirectories: true)

            let jobInfoURL    = tmpDir.appendingPathComponent("jobInfo.job")
            let pluginInfoURL = tmpDir.appendingPathComponent("pluginInfo.job")

            try writeFFmpegJobInfo(to: jobInfoURL, input: input, output: output, settings: settings)
            try writeFFmpegPluginInfo(to: pluginInfoURL,
                                      input: input,
                                      output: output,
                                      ffmpegPath: ffmpegPath,
                                      outputArgs: outputArgs)

            let (code, out) = runCLI(path: deadlineCmd,
                                     args: ["-SubmitJob", jobInfoURL.path, pluginInfoURL.path])
            let jobID = code == 0 ? parseDeadlineJobID(out) : nil

            try? fm.removeItem(at: tmpDir)
            return SubmissionResult(input: input, output: output, exitCode: code, rawOutput: out, jobID: jobID)
        } catch {
            try? fm.removeItem(at: tmpDir)
            return SubmissionResult(input: input, output: output,
                                    exitCode: -1,
                                    rawOutput: "Failed to write/submit Deadline job: \(error)",
                                    jobID: nil)
        }
    }

    // MARK: - FFmpeg plugin helpers
    
    private static func ffmpegOutputArgs(fromFullArgs full: [String], input: URL, output: URL) -> String {
        var args = full
        
        // Remove the executable name if it's there
        if let first = args.first, first.contains("ffmpeg") {
            args.removeFirst()
        }
        
        // Remove -hide_banner if present
        args.removeAll { $0 == "-hide_banner" }
        
        // Remove the input file arguments (-i and the path)
        if let iIdx = args.firstIndex(of: "-i") {
            if iIdx + 1 < args.count && args[iIdx + 1] == input.path {
                args.removeSubrange(iIdx...iIdx+1)
            } else if iIdx < args.count {
                args.remove(at: iIdx)
            }
        }
        
        // Remove the output file path (should be last argument)
        if let last = args.last, last == output.path {
            args.removeLast()
        }
        
        // Remove any stray pipe: arguments that might cause issues
        args.removeAll { $0 == "pipe:" || $0.contains("pipe:") }
        
        // Clean up any empty arguments
        args.removeAll { $0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        
        let result = args.joined(separator: " ")
        
        // Debug logging to help diagnose issues
        print("🔧 FFmpeg output args: \(result)")
        
        return result
    }

    private static func parseDeadlineJobID(_ output: String) -> String? {
        let patterns = [
            "[Jj]ob[ ]?ID[ =:]+([A-Za-z0-9_-]+)",
            "[0-9a-fA-F]{24}"
        ]

        for pattern in patterns {
            guard let regex = try? NSRegularExpression(pattern: pattern, options: []) else { continue }
            let fullRange = NSRange(output.startIndex..<output.endIndex, in: output)
            if let match = regex.firstMatch(in: output, options: [], range: fullRange) {
                if match.numberOfRanges > 1,
                   let range = Range(match.range(at: 1), in: output) {
                    return String(output[range]).trimmingCharacters(in: .whitespacesAndNewlines)
                } else if let range = Range(match.range(at: 0), in: output) {
                    return String(output[range]).trimmingCharacters(in: .whitespacesAndNewlines)
                }
            }
        }
        return nil
    }

    private static func writeFFmpegJobInfo(to url: URL, input: URL, output: URL, settings: Settings) throws {
        var lines: [String] = []
        let name = settings.jobName.isEmpty
            ? output.deletingPathExtension().lastPathComponent
            : settings.jobName
        lines.append("Name=\(escapeJobField(name))")
        if !settings.batchName.isEmpty { lines.append("BatchName=\(escapeJobField(settings.batchName))") }
        if !settings.comment.isEmpty   { lines.append("Comment=\(escapeJobField(settings.comment))") }
        if !settings.pool.isEmpty          { lines.append("Pool=\(escapeJobField(settings.pool))") }
        if !settings.secondaryPool.isEmpty { lines.append("SecondaryPool=\(escapeJobField(settings.secondaryPool))") }
        if !settings.group.isEmpty         { lines.append("Group=\(escapeJobField(settings.group))") }
        lines.append("Priority=\(settings.priority)")
        lines.append("Plugin=FFmpeg")
        lines.append("Frames=0")
        lines.append("ChunkSize=1")
        lines.append("OutputDirectory0=\(output.deletingLastPathComponent().path)")
        lines.append("OutputFilename0=\(output.lastPathComponent)")
        try lines.joined(separator: "\n").appending("\n").write(to: url, atomically: true, encoding: .utf8)
    }

    private static func writeFFmpegPluginInfo(to url: URL,
                                              input: URL,
                                              output: URL,
                                              ffmpegPath: String,
                                              outputArgs: String) throws {
        var lines: [String] = []
        lines.append("InputFile0=\(input.path)")
        lines.append("InputArgs0=")
        lines.append("ReplacePadding0=False")
        lines.append("OutputFile=\(output.path)")
        lines.append("OutputArgs=\(outputArgs)")
        lines.append("UseSameInputArgs=False")
        lines.append("AdditionalArgs=")
        lines.append("VideoPreset=")
        lines.append("AudioPreset=")
        lines.append("SubtitlePreset=")
        try lines.joined(separator: "\n").appending("\n").write(to: url, atomically: true, encoding: .utf8)
    }

    // MARK: - CLI utilities
    
    static func runCLI(path: String, args: [String]) -> (Int32, String) {
        let task = Process()
        task.executableURL = URL(fileURLWithPath: path)
        task.arguments = args
        let pipe = Pipe()
        task.standardOutput = pipe
        task.standardError  = pipe
        do { try task.run() } catch { return (-1, "Failed to launch \(path): \(error)") }
        task.waitUntilExit()
        let out = String(decoding: pipe.fileHandleForReading.readDataToEndOfFile(), as: UTF8.self)
        return (task.terminationStatus, out)
    }

    private static func runAndCollect(_ cmd: String, _ args: [String]) throws -> [String] {
        let (code, out) = runCLI(path: cmd, args: args)
        guard code == 0 else {
            throw NSError(domain: "Deadline", code: Int(code),
                          userInfo: [NSLocalizedDescriptionKey: out])
        }
        return out.split(whereSeparator: \.isNewline).map { String($0).trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
    }

    private static func escapeJobField(_ s: String) -> String {
        s.replacingOccurrences(of: "\n", with: " ").trimmingCharacters(in: .whitespacesAndNewlines)
    }

    // MARK: - Path sanity
    
    static func isInputPathAcceptableForFarm(_ url: URL) -> Result<Void, DropletError> {
        let path = url.path
        let home = FileManager.default.homeDirectoryForCurrentUser.path
        let forbidden = [home + "/Desktop", home + "/Downloads"]
        if forbidden.contains(where: { path.hasPrefix($0 + "/") || path == $0 }) {
            return .failure(.validation(message: "Path is under \(home)/Desktop or /Downloads; farm nodes won't see this."))
        }
        if path.hasPrefix(home + "/") && !path.hasPrefix("/Volumes/") {
            return .failure(.validation(message: "Path is under your local home folder. Use a shared path (e.g. /Volumes/Share/…)."))
        }
        if path.hasPrefix("/Volumes/") { return .success(()) }
        return .success(())
    }

    // MARK: - Detail builders for messages
    
    /// Build detailed success information for copy-to-clipboard
    private static func buildSuccessDetail(jobID: String?, output: String) -> String {
        var lines: [String] = []
        
        lines.append("=== Deadline Submission Success ===")
        
        if let jid = jobID, !jid.isEmpty {
            lines.append("Job ID: \(jid)")
        }
        
        lines.append("Timestamp: \(DateFormatter.messageTimestamp.string(from: Date()))")
        lines.append("")
        lines.append("=== Deadline Output ===")
        lines.append(output.trimmingCharacters(in: .whitespacesAndNewlines))
        
        return lines.joined(separator: "\n")
    }
    
    /// Build detailed error information for copy-to-clipboard
    private static func buildErrorDetail(exitCode: Int32, output: String) -> String {
        var lines: [String] = []
        
        lines.append("=== Deadline Submission Failed ===")
        lines.append("Exit Code: \(exitCode)")
        lines.append("Timestamp: \(DateFormatter.messageTimestamp.string(from: Date()))")
        lines.append("")
        lines.append("=== Deadline Output ===")
        lines.append(output.trimmingCharacters(in: .whitespacesAndNewlines))
        
        return lines.joined(separator: "\n")
    }

    // MARK: - JobID extraction (for concise success messages)

    /// Try to extract a JobID from Deadline CLI output.
    private static func extractDeadlineJobID(from s: String) -> String? {
        // Common Deadline output shape:
        // "Job submitted successfully: SomeName [62c7d1f9e44adf2b3f35e0c7]"
        if let m = s.range(of: #"\[([0-9a-f]{24})\]"#, options: .regularExpression) {
            return String(s[m]).trimmingCharacters(in: CharacterSet(charactersIn: "[]"))
        }
        // Fallback: first 24-hex token
        if let m = s.range(of: #"[0-9a-f]{24}"#, options: .regularExpression) {
            return String(s[m])
        }
        return nil
    }
}

// MARK: - DateFormatter Extension
extension DateFormatter {
    static let messageTimestamp: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .medium
        return formatter
    }()
}

